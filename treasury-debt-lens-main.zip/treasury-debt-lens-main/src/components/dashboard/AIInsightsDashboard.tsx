import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Brain, 
  Activity, 
  Target, 
  Zap,
  TrendingUp,
  BarChart3,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

interface YieldPrediction {
  id: string;
  prediction_date: string;
  target_date: string;
  maturity: string;
  predicted_yield: number;
  confidence_interval_lower: number;
  confidence_interval_upper: number;
  model_version: string;
  actual_yield: number | null;
}

interface AIModelRun {
  id: string;
  model_type: string;
  input_data: any;
  output_data: any;
  model_version: string;
  confidence_score: number;
  execution_time_ms: number;
  created_at: string;
}

const AIInsightsDashboard = () => {
  const [predictions, setPredictions] = useState<YieldPrediction[]>([]);
  const [modelRuns, setModelRuns] = useState<AIModelRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [forecasting, setForecasting] = useState(false);
  const [selectedMaturity, setSelectedMaturity] = useState('10Y');
  const [horizonDays, setHorizonDays] = useState('30');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [predictionsResponse, modelRunsResponse] = await Promise.all([
          supabase.from('yield_predictions').select('*').order('prediction_date', { ascending: false }).limit(20),
          supabase.from('ai_model_runs').select('*').order('created_at', { ascending: false }).limit(20)
        ]);

        if (predictionsResponse.data) setPredictions(predictionsResponse.data);
        if (modelRunsResponse.data) setModelRuns(modelRunsResponse.data);
      } catch (error) {
        console.error('Error fetching AI data:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch AI insights data",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleYieldForecasting = async (e: React.FormEvent) => {
    e.preventDefault();
    setForecasting(true);

    try {
      const { data, error } = await supabase.functions.invoke('forecast-yields', {
        body: JSON.stringify({
          maturity: selectedMaturity,
          horizon_days: parseInt(horizonDays)
        })
      });

      if (error) throw error;

      toast({
        title: "Forecast Generated",
        description: `${selectedMaturity} yield forecast for ${horizonDays} days completed`,
      });

      // Refresh predictions
      const { data: newPredictions } = await supabase
        .from('yield_predictions')
        .select('*')
        .order('prediction_date', { ascending: false })
        .limit(20);

      if (newPredictions) setPredictions(newPredictions);

    } catch (error: any) {
      console.error('Forecasting error:', error);
      toast({
        variant: "destructive",
        title: "Forecast Failed",
        description: error.message || "Failed to generate yield forecast",
      });
    } finally {
      setForecasting(false);
    }
  };

  const ModelPerformanceCard = () => {
    const accuracyData = predictions
      .filter(p => p.actual_yield !== null)
      .map(p => ({
        ...p,
        accuracy: 100 - Math.abs((p.predicted_yield - p.actual_yield!) / p.actual_yield! * 100)
      }));

    const avgAccuracy = accuracyData.length > 0 
      ? accuracyData.reduce((acc, p) => acc + p.accuracy, 0) / accuracyData.length 
      : 0;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Model Performance
          </CardTitle>
          <CardDescription>AI model accuracy and confidence metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 border rounded-lg text-center">
                <div className="text-2xl font-bold text-green-600">
                  {avgAccuracy.toFixed(1)}%
                </div>
                <div className="text-xs text-muted-foreground">Avg Accuracy</div>
              </div>
              <div className="p-3 border rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {predictions.length}
                </div>
                <div className="text-xs text-muted-foreground">Total Predictions</div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Model Confidence</span>
                <span>85%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-primary h-2 rounded-full w-[85%]"></div>
              </div>
            </div>

            <div className="space-y-2">
              {['Yield Forecasting', 'Fed Prediction', 'ESG Classification'].map((model, index) => (
                <div key={model} className="flex items-center justify-between p-2 border rounded">
                  <span className="text-sm">{model}</span>
                  <Badge variant={index === 0 ? 'default' : 'secondary'}>
                    {index === 0 ? 'Active' : 'Planned'}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const YieldForecastCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          Yield Forecasting
        </CardTitle>
        <CardDescription>Generate AI-powered yield predictions</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleYieldForecasting} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maturity">Maturity</Label>
              <Select value={selectedMaturity} onValueChange={setSelectedMaturity}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2Y">2 Year</SelectItem>
                  <SelectItem value="5Y">5 Year</SelectItem>
                  <SelectItem value="10Y">10 Year</SelectItem>
                  <SelectItem value="30Y">30 Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="horizon">Forecast Horizon (Days)</Label>
              <Select value={horizonDays} onValueChange={setHorizonDays}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 Days</SelectItem>
                  <SelectItem value="30">30 Days</SelectItem>
                  <SelectItem value="90">90 Days</SelectItem>
                  <SelectItem value="180">180 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={forecasting} className="w-full">
            {forecasting ? (
              <>
                <Clock className="h-4 w-4 mr-2 animate-spin" />
                Generating Forecast...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Generate Forecast
              </>
            )}
          </Button>
        </form>

        {predictions.length > 0 && (
          <div className="mt-6 space-y-3">
            <h4 className="font-medium">Recent Predictions</h4>
            {predictions.slice(0, 3).map((prediction) => (
              <div key={prediction.id} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline">{prediction.maturity}</Badge>
                  <span className="text-sm text-muted-foreground">
                    {new Date(prediction.prediction_date).toLocaleDateString()}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="text-center">
                    <div className="font-bold">{prediction.predicted_yield.toFixed(2)}%</div>
                    <div className="text-xs text-muted-foreground">Prediction</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">
                      {prediction.confidence_interval_lower.toFixed(2)}-{prediction.confidence_interval_upper.toFixed(2)}%
                    </div>
                    <div className="text-xs text-muted-foreground">Confidence</div>
                  </div>
                  <div className="text-center">
                    <div className="font-bold">
                      {prediction.actual_yield ? prediction.actual_yield.toFixed(2) + '%' : 'Pending'}
                    </div>
                    <div className="text-xs text-muted-foreground">Actual</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );

  const ModelAuditCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Model Audit Trail
        </CardTitle>
        <CardDescription>Complete logging of AI decisions for compliance</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {modelRuns.slice(0, 5).map((run) => (
            <div key={run.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className={`h-2 w-2 rounded-full ${
                  run.confidence_score > 0.8 ? 'bg-green-500' : 
                  run.confidence_score > 0.6 ? 'bg-yellow-500' : 'bg-red-500'
                }`} />
                <div>
                  <div className="font-medium capitalize">
                    {run.model_type.replace('_', ' ')}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(run.created_at).toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold">{Math.round(run.confidence_score * 100)}%</div>
                <div className="text-xs text-muted-foreground">
                  {run.execution_time_ms}ms
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const ExplainableAICard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          Explainable AI
        </CardTitle>
        <CardDescription>Model interpretability and feature importance</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-3">
            <h4 className="font-medium">Key Factors in Yield Predictions</h4>
            {[
              { factor: 'Historical Volatility', importance: 85 },
              { factor: 'Fed Rate Expectations', importance: 78 },
              { factor: 'Economic Indicators', importance: 65 },
              { factor: 'Geopolitical Events', importance: 45 },
              { factor: 'Market Sentiment', importance: 32 }
            ].map((item) => (
              <div key={item.factor} className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>{item.factor}</span>
                  <span>{item.importance}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all" 
                    style={{ width: `${item.importance}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <AlertCircle className="h-4 w-4" />
              Model decisions are fully auditable and explainable for regulatory compliance
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array(4).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-8 bg-muted rounded w-1/2"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded"></div>
                    <div className="h-3 bg-muted rounded w-5/6"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Model Accuracy</p>
                <p className="text-2xl font-bold">
                  {predictions.filter(p => p.actual_yield !== null).length > 0 
                    ? (predictions
                        .filter(p => p.actual_yield !== null)
                        .reduce((acc, p) => acc + (100 - Math.abs((p.predicted_yield - p.actual_yield!) / p.actual_yield! * 100)), 0) 
                      / predictions.filter(p => p.actual_yield !== null).length
                      ).toFixed(1) 
                    : '0.0'}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Predictions Made</p>
                <p className="text-2xl font-bold">{predictions.length}</p>
              </div>
              <Target className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Confidence</p>
                <p className="text-2xl font-bold">
                  {modelRuns.length > 0 
                    ? Math.round(modelRuns.reduce((acc, run) => acc + run.confidence_score, 0) / modelRuns.length * 100)
                    : 0}%
                </p>
              </div>
              <Brain className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Model Runs</p>
                <p className="text-2xl font-bold">{modelRuns.length}</p>
              </div>
              <Activity className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="forecasting" className="space-y-6">
        <TabsList>
          <TabsTrigger value="forecasting">Forecasting</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="explainable">Explainable AI</TabsTrigger>
          <TabsTrigger value="audit">Audit Trail</TabsTrigger>
        </TabsList>

        <TabsContent value="forecasting" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <YieldForecastCard />
            <ModelPerformanceCard />
          </div>
        </TabsContent>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Model Performance Analytics</CardTitle>
              <CardDescription>Detailed accuracy tracking and backtesting results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {predictions.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Model Accuracy Over Time</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {predictions.slice(0, 8).map((prediction, index) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <Badge variant="outline">{prediction.maturity}</Badge>
                            <span className="text-sm text-muted-foreground">
                              {new Date(prediction.prediction_date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <div>
                              <div className="text-xs text-muted-foreground">Predicted</div>
                              <div className="font-bold">{prediction.predicted_yield.toFixed(2)}%</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground">Actual</div>
                              <div className="font-bold">
                                {prediction.actual_yield ? prediction.actual_yield.toFixed(2) + '%' : 'Pending'}
                              </div>
                            </div>
                          </div>
                          {prediction.actual_yield && (
                            <div className="mt-2">
                              <div className="text-xs text-muted-foreground">Accuracy</div>
                              <div className="font-bold text-green-600">
                                {(100 - Math.abs((prediction.predicted_yield - prediction.actual_yield) / prediction.actual_yield * 100)).toFixed(1)}%
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No performance data available. Generate some predictions to track accuracy.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="explainable">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ExplainableAICard />
            <Card>
              <CardHeader>
                <CardTitle>Decision Trees</CardTitle>
                <CardDescription>Visual representation of model decision paths</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96 flex items-center justify-center text-muted-foreground">
                  Decision tree visualization would be rendered here
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="audit">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ModelAuditCard />
            <Card>
              <CardHeader>
                <CardTitle>Compliance Reports</CardTitle>
                <CardDescription>Regulatory compliance and model validation</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 p-3 border rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span>SOC 2 Compliance</span>
                  </div>
                  <div className="flex items-center gap-2 p-3 border rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span>Model Risk Management</span>
                  </div>
                  <div className="flex items-center gap-2 p-3 border rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span>Audit Trail Complete</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AIInsightsDashboard;