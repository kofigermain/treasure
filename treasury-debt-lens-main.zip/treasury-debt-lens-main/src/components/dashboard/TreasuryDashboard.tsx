import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  AlertTriangle,
  DollarSign,
  Target,
  Gauge
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface YieldData {
  date: string;
  maturity: string;
  yield_rate: number;
}

interface FedMeeting {
  meeting_date: string;
  fed_funds_rate: number | null;
  rate_decision: string | null;
  ai_summary: string | null;
}

const TreasuryDashboard = () => {
  const [yieldData, setYieldData] = useState<YieldData[]>([]);
  const [fedMeetings, setFedMeetings] = useState<FedMeeting[]>([]);
  const [institutionalFlows, setInstitutionalFlows] = useState<any[]>([]);
  const [predictions, setPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [yieldsResponse, fedResponse, flowsResponse, predictionsResponse] = await Promise.all([
          supabase.from('treasury_yields').select('*').order('date', { ascending: false }).limit(100),
          supabase.from('fed_meetings').select('*').order('meeting_date', { ascending: false }).limit(10),
          supabase.from('institutional_flows').select('*').order('date', { ascending: false }).limit(20),
          supabase.from('yield_predictions').select('*').order('prediction_date', { ascending: false }).limit(50)
        ]);

        if (yieldsResponse.data) setYieldData(yieldsResponse.data);
        if (fedResponse.data) setFedMeetings(fedResponse.data);
        if (flowsResponse.data) setInstitutionalFlows(flowsResponse.data);
        if (predictionsResponse.data) setPredictions(predictionsResponse.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const getLatestYieldByMaturity = (maturity: string) => {
    const filtered = yieldData.filter(y => y.maturity === maturity);
    return filtered.length > 0 ? filtered[0] : null;
  };

  const maturities = ['2Y', '5Y', '10Y', '30Y'];
  const currentYields = maturities.map(m => getLatestYieldByMaturity(m)).filter(Boolean);

  const YieldCurveCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Current Yield Curve
        </CardTitle>
        <CardDescription>Latest US Treasury yields across maturities</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {currentYields.map((yield_data) => (
            <div key={yield_data.maturity} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant="outline">{yield_data.maturity}</Badge>
                <span className="font-medium">{yield_data.maturity} Treasury</span>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">{yield_data.yield_rate.toFixed(2)}%</div>
                <div className="text-xs text-muted-foreground">
                  {new Date(yield_data.date).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const FedPolicyCard = () => {
    const latestMeeting = fedMeetings[0];
    
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Fed Policy Tracker
          </CardTitle>
          <CardDescription>Federal Reserve rate decisions and outlook</CardDescription>
        </CardHeader>
        <CardContent>
          {latestMeeting ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <div className="font-medium">Current Fed Funds Rate</div>
                  <div className="text-xs text-muted-foreground">
                    Last updated: {new Date(latestMeeting.meeting_date).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold">
                    {latestMeeting.fed_funds_rate?.toFixed(2) || 'N/A'}%
                  </div>
                  {latestMeeting.rate_decision && (
                    <Badge 
                      variant={latestMeeting.rate_decision === 'increase' ? 'destructive' : 
                              latestMeeting.rate_decision === 'decrease' ? 'default' : 'secondary'}
                    >
                      {latestMeeting.rate_decision}
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="p-3 border rounded-lg">
                  <div className="text-sm text-muted-foreground">Next Meeting</div>
                  <div className="font-medium">Mar 20</div>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="text-sm text-muted-foreground">Probability</div>
                  <div className="font-medium">65% Hold</div>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="text-sm text-muted-foreground">Market Exp.</div>
                  <div className="font-medium">-25 bps</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-muted-foreground py-8">
              No Fed meeting data available
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const MarketMetricsCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Market Stress Indicators
        </CardTitle>
        <CardDescription>Real-time market stress and volatility metrics</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 border rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">VIX</span>
                <TrendingDown className="h-4 w-4 text-green-500" />
              </div>
              <div className="text-xl font-bold">18.5</div>
              <div className="text-xs text-green-600">-2.3%</div>
            </div>
            <div className="p-3 border rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Term Spread</span>
                <TrendingUp className="h-4 w-4 text-red-500" />
              </div>
              <div className="text-xl font-bold">-0.45%</div>
              <div className="text-xs text-red-600">Inverted</div>
            </div>
          </div>
          
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />
              <div>
                <div className="text-sm font-medium text-yellow-800">Market Alert</div>
                <div className="text-xs text-yellow-700">
                  Yield curve inversion detected. Monitor for recession signals.
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const InstitutionalFlowsCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <DollarSign className="h-5 w-5" />
          Institutional Flows
        </CardTitle>
        <CardDescription>Large institutional treasury transactions</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {[
            { type: 'Foreign Central Bank', direction: 'Buy', amount: '$2.3B', security: '10Y', time: '2h ago' },
            { type: 'Pension Fund', direction: 'Sell', amount: '$890M', security: '30Y', time: '4h ago' },
            { type: 'Hedge Fund', direction: 'Buy', amount: '$1.1B', security: '2Y', time: '6h ago' },
          ].map((flow, index) => (
            <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant="outline">{flow.security}</Badge>
                <div>
                  <div className="font-medium">{flow.type}</div>
                  <div className="text-xs text-muted-foreground">{flow.time}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold">{flow.amount}</div>
                <Badge variant={flow.direction === 'Buy' ? 'default' : 'secondary'}>
                  {flow.direction}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-8 bg-muted rounded w-1/2"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded"></div>
                    <div className="h-3 bg-muted rounded w-5/6"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">10Y Yield</p>
                <p className="text-2xl font-bold">
                  {getLatestYieldByMaturity('10Y')?.yield_rate.toFixed(2) || 'N/A'}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">2Y-10Y Spread</p>
                <p className="text-2xl font-bold">-0.45%</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Fed Funds</p>
                <p className="text-2xl font-bold">
                  {fedMeetings[0]?.fed_funds_rate?.toFixed(2) || 'N/A'}%
                </p>
              </div>
              <Target className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Market Stress</p>
                <p className="text-2xl font-bold">Moderate</p>
              </div>
              <Gauge className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="yields">Yield Analysis</TabsTrigger>
          <TabsTrigger value="flows">Institutional Flows</TabsTrigger>
          <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <YieldCurveCard />
            <FedPolicyCard />
            <MarketMetricsCard />
            <InstitutionalFlowsCard />
          </div>
        </TabsContent>

        <TabsContent value="yields">
          <Card>
            <CardHeader>
              <CardTitle>Yield Curve Analysis</CardTitle>
              <CardDescription>Detailed Treasury yield analysis and historical trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {yieldData.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Recent Yield Trends</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {yieldData.slice(0, 12).map((yield_data, index) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{yield_data.maturity}</Badge>
                              <span className="text-sm">{new Date(yield_data.date).toLocaleDateString()}</span>
                            </div>
                            <div className="text-xl font-bold">{yield_data.yield_rate.toFixed(2)}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No yield data available. Initialize data to populate charts.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flows">
          <Card>
            <CardHeader>
              <CardTitle>Institutional Flow Monitor</CardTitle>
              <CardDescription>Real-time tracking of large institutional treasury transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {institutionalFlows.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Recent Institutional Activity</h3>
                    <div className="space-y-3">
                      {institutionalFlows.slice(0, 8).map((flow, index) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <Badge variant="outline">{flow.security_type || 'Treasury'}</Badge>
                            <div>
                              <div className="font-medium">{flow.flow_type || 'Institutional Flow'}</div>
                              <div className="text-xs text-muted-foreground">
                                {new Date(flow.date).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold">
                              ${flow.volume_usd ? (flow.volume_usd / 1000000).toFixed(1) : '0'}M
                            </div>
                            <Badge variant={flow.direction === 'Buy' ? 'default' : 'secondary'}>
                              {flow.direction || 'N/A'}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No institutional flow data available. Check back later for real-time updates.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions">
          <Card>
            <CardHeader>
              <CardTitle>AI Yield Predictions</CardTitle>
              <CardDescription>Machine learning forecasts for Treasury yields</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {predictions.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">AI Forecast Results</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {predictions.slice(0, 8).map((prediction, index) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">{prediction.maturity}</Badge>
                              <span className="text-sm">
                                {new Date(prediction.target_date).toLocaleDateString()}
                              </span>
                            </div>
                            <div className="text-xl font-bold">
                              {prediction.predicted_yield?.toFixed(2) || 'N/A'}%
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Confidence: {prediction.confidence_interval_lower?.toFixed(2)}% - {prediction.confidence_interval_upper?.toFixed(2)}%
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="text-sm font-medium text-blue-800">Model Performance</div>
                      <div className="text-xs text-blue-600 mt-1">
                        Latest predictions generated with 85% confidence interval
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No AI predictions available. Run the forecast model to generate predictions.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default TreasuryDashboard;