import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Globe, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  FileText,
  Upload,
  BarChart3,
  Target
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/use-toast';

interface Country {
  id: string;
  name: string;
  iso_code: string;
  region: string;
  income_level: string;
  population: number;
  gdp_usd: number;
}

interface SovereignDebt {
  id: string;
  country_id: string;
  year: number;
  debt_to_gdp: number;
  external_debt_usd: number;
  domestic_debt_usd: number;
  debt_service_ratio: number;
  countries: Country;
}

interface ESGScore {
  id: string;
  country_id: string;
  assessment_date: string;
  environmental_score: number;
  social_score: number;
  governance_score: number;
  overall_score: number;
  fiscal_transparency_score: number;
  debt_sustainability_score: number;
  countries: Country;
}

const SovereignDashboard = () => {
  const [countries, setCountries] = useState<Country[]>([]);
  const [sovereignDebt, setSovereignDebt] = useState<SovereignDebt[]>([]);
  const [esgScores, setESGScores] = useState<ESGScore[]>([]);
  const [recentAnalyses, setRecentAnalyses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadingBudget, setUploadingBudget] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const [fiscalYear, setFiscalYear] = useState<string>('2024');
  const [currency, setCurrency] = useState<string>('USD');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [countriesResponse, debtResponse, esgResponse, budgetResponse] = await Promise.all([
          supabase.from('countries').select('*').order('name'),
          supabase.from('sovereign_debt').select(`
            *,
            countries (id, name, iso_code, region, income_level, population, gdp_usd)
          `).order('year', { ascending: false }).limit(50),
          supabase.from('esg_scores').select(`
            *,
            countries (id, name, iso_code, region, income_level, population, gdp_usd)
          `).order('assessment_date', { ascending: false }).limit(50),
          supabase.from('government_budgets').select(`
            *,
            countries (id, name, iso_code)
          `).order('processed_at', { ascending: false }).limit(10)
        ]);

        if (countriesResponse.data) setCountries(countriesResponse.data);
        if (debtResponse.data) setSovereignDebt(debtResponse.data as any);
        if (esgResponse.data) setESGScores(esgResponse.data as any);
        if (budgetResponse.data) setRecentAnalyses(budgetResponse.data as any);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch sovereign data",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleBudgetUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCountry || !fiscalYear || !currency) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill in all required fields",
      });
      return;
    }

    const fileInput = document.getElementById('budget-file') as HTMLInputElement;
    const file = fileInput?.files?.[0];

    if (!file) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please select a budget document",
      });
      return;
    }

    setUploadingBudget(true);

    try {
      const formData = new FormData();
      formData.append('budget_file', file);
      formData.append('country_id', selectedCountry);
      formData.append('fiscal_year', fiscalYear);
      formData.append('currency', currency);

      const { data, error } = await supabase.functions.invoke('analyze-budget', {
        body: formData,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Budget document analyzed successfully",
      });

      // Refresh recent analyses
      const budgetResponse = await supabase.from('government_budgets').select(`
        *,
        countries (id, name, iso_code)
      `).order('processed_at', { ascending: false }).limit(10);
      
      if (budgetResponse.data) setRecentAnalyses(budgetResponse.data as any);

      // Reset form
      fileInput.value = '';
      setSelectedCountry('');
      setFiscalYear('2024');
      setCurrency('USD');

    } catch (error: any) {
      console.error('Budget upload error:', error);
      toast({
        variant: "destructive",
        title: "Upload Failed",
        description: error.message || "Failed to analyze budget document",
      });
    } finally {
      setUploadingBudget(false);
    }
  };

  const DebtMapCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Global Debt Overview
        </CardTitle>
        <CardDescription>Debt-to-GDP ratios by country</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sovereignDebt.slice(0, 6).map((debt) => (
            <div key={debt.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <Badge variant="outline">{debt.countries.iso_code}</Badge>
                <div>
                  <div className="font-medium">{debt.countries.name}</div>
                  <div className="text-xs text-muted-foreground">{debt.year}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xl font-bold">{debt.debt_to_gdp}%</div>
                <div className={`text-xs flex items-center gap-1 ${
                  debt.debt_to_gdp > 90 ? 'text-red-600' : 
                  debt.debt_to_gdp > 60 ? 'text-yellow-600' : 'text-green-600'
                }`}>
                  {debt.debt_to_gdp > 90 ? <AlertTriangle className="h-3 w-3" /> : 
                   debt.debt_to_gdp > 60 ? <TrendingUp className="h-3 w-3" /> : 
                   <TrendingDown className="h-3 w-3" />}
                  {debt.debt_to_gdp > 90 ? 'High Risk' : 
                   debt.debt_to_gdp > 60 ? 'Moderate' : 'Stable'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const ESGScorecardCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5" />
          ESG Scorecard
        </CardTitle>
        <CardDescription>Environmental, Social, and Governance scores</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {esgScores.slice(0, 5).map((score) => (
            <div key={score.id} className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{score.countries.iso_code}</Badge>
                  <span className="font-medium">{score.countries.name}</span>
                </div>
                <div className="text-xl font-bold">{score.overall_score}/100</div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-sm">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground">Environmental</div>
                  <div className="font-medium">{score.environmental_score}</div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground">Social</div>
                  <div className="font-medium">{score.social_score}</div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground">Governance</div>
                  <div className="font-medium">{score.governance_score}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const BudgetAnalysisCard = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Budget AI Analysis
        </CardTitle>
        <CardDescription>Upload government budget documents for AI analysis</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleBudgetUpload} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="country">Country</Label>
            <Select value={selectedCountry} onValueChange={setSelectedCountry}>
              <SelectTrigger>
                <SelectValue placeholder="Select country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country.id} value={country.id}>
                    {country.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fiscal-year">Fiscal Year</Label>
              <Input
                id="fiscal-year"
                type="number"
                value={fiscalYear}
                onChange={(e) => setFiscalYear(e.target.value)}
                min="2000"
                max="2030"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="budget-file">Budget Document</Label>
            <Input
              id="budget-file"
              type="file"
              accept=".pdf,.txt,.doc,.docx"
              className="cursor-pointer"
            />
          </div>

          <Button type="submit" disabled={uploadingBudget} className="w-full">
            {uploadingBudget ? (
              'Analyzing...'
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Analyze Budget Document
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-8 bg-muted rounded w-1/2"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded"></div>
                    <div className="h-3 bg-muted rounded w-5/6"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Countries Tracked</p>
                <p className="text-2xl font-bold">{countries.length}</p>
              </div>
              <Globe className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Debt/GDP</p>
                <p className="text-2xl font-bold">
                  {sovereignDebt.length > 0 
                    ? Math.round(sovereignDebt.reduce((acc, debt) => acc + debt.debt_to_gdp, 0) / sovereignDebt.length)
                    : 0}%
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg ESG Score</p>
                <p className="text-2xl font-bold">
                  {esgScores.length > 0 
                    ? Math.round(esgScores.reduce((acc, score) => acc + score.overall_score, 0) / esgScores.length)
                    : 0}
                </p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Risk</p>
                <p className="text-2xl font-bold">
                  {sovereignDebt.filter(debt => debt.debt_to_gdp > 90).length}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="debt-analysis">Debt Analysis</TabsTrigger>
          <TabsTrigger value="esg-scores">ESG Scores</TabsTrigger>
          <TabsTrigger value="budget-ai">Budget AI</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DebtMapCard />
            <ESGScorecardCard />
          </div>
        </TabsContent>

        <TabsContent value="debt-analysis">
          <Card>
            <CardHeader>
              <CardTitle>Sovereign Debt Analysis</CardTitle>
              <CardDescription>Detailed debt metrics and sustainability analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {sovereignDebt.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Debt-to-GDP Trends</h3>
                      <div className="space-y-3">
                        {sovereignDebt.slice(0, 8).map((debt) => (
                          <div key={debt.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center gap-3">
                              <Badge variant="outline">{debt.countries.iso_code}</Badge>
                              <div>
                                <div className="font-medium">{debt.countries.name}</div>
                                <div className="text-xs text-muted-foreground">{debt.year}</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold">{debt.debt_to_gdp}%</div>
                              <div className={`text-xs ${
                                debt.debt_to_gdp > 90 ? 'text-red-600' : 
                                debt.debt_to_gdp > 60 ? 'text-yellow-600' : 'text-green-600'
                              }`}>
                                {debt.debt_to_gdp > 90 ? 'High Risk' : 
                                 debt.debt_to_gdp > 60 ? 'Moderate' : 'Low Risk'}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-4">Regional Analysis</h3>
                      <div className="space-y-3">
                        <div className="p-4 border rounded-lg">
                          <div className="text-sm text-muted-foreground">Europe & Central Asia</div>
                          <div className="text-2xl font-bold">67.5%</div>
                          <div className="text-xs text-yellow-600">Average Debt/GDP</div>
                        </div>
                        <div className="p-4 border rounded-lg">
                          <div className="text-sm text-muted-foreground">East Asia & Pacific</div>
                          <div className="text-2xl font-bold">45.2%</div>
                          <div className="text-xs text-green-600">Average Debt/GDP</div>
                        </div>
                        <div className="p-4 border rounded-lg">
                          <div className="text-sm text-muted-foreground">North America</div>
                          <div className="text-2xl font-bold">89.3%</div>
                          <div className="text-xs text-red-600">Average Debt/GDP</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No sovereign debt data available. Initialize data to populate analytics.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="esg-scores">
          <Card>
            <CardHeader>
              <CardTitle>ESG Score Analysis</CardTitle>
              <CardDescription>Environmental, Social, and Governance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96">
                {esgScores.length > 0 ? (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
                    <div>
                      <h3 className="text-lg font-semibold mb-4">ESG Performance by Country</h3>
                      <div className="space-y-3">
                        {esgScores.slice(0, 6).map((score) => (
                          <div key={score.id} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline">{score.countries.iso_code}</Badge>
                                <span className="font-medium">{score.countries.name}</span>
                              </div>
                              <div className="text-xl font-bold">{score.overall_score}/100</div>
                            </div>
                            <div className="grid grid-cols-3 gap-2 text-xs">
                              <div className="text-center">
                                <div className="text-muted-foreground">E</div>
                                <div className="font-medium">{score.environmental_score}</div>
                              </div>
                              <div className="text-center">
                                <div className="text-muted-foreground">S</div>
                                <div className="font-medium">{score.social_score}</div>
                              </div>
                              <div className="text-center">
                                <div className="text-muted-foreground">G</div>
                                <div className="font-medium">{score.governance_score}</div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-4">ESG Distribution</h3>
                      <div className="space-y-4">
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-sm">High ESG (80+)</span>
                            <span className="font-bold">
                              {esgScores.filter(s => s.overall_score >= 80).length} countries
                            </span>
                          </div>
                        </div>
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-sm">Medium ESG (60-79)</span>
                            <span className="font-bold">
                              {esgScores.filter(s => s.overall_score >= 60 && s.overall_score < 80).length} countries
                            </span>
                          </div>
                        </div>
                        <div className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="text-sm">Low ESG (&lt;60)</span>
                            <span className="font-bold">
                              {esgScores.filter(s => s.overall_score < 60).length} countries
                            </span>
                          </div>
                        </div>
                        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <div className="text-sm font-medium text-blue-800 mb-1">Average ESG Score</div>
                          <div className="text-3xl font-bold text-blue-900">
                            {esgScores.length > 0 
                              ? Math.round(esgScores.reduce((acc, score) => acc + score.overall_score, 0) / esgScores.length)
                              : 0}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    No ESG data available. Initialize data to populate analytics.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budget-ai">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <BudgetAnalysisCard />
            <Card>
              <CardHeader>
                <CardTitle>Recent Analyses</CardTitle>
                <CardDescription>Latest AI budget analysis results</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentAnalyses.length > 0 ? (
                    recentAnalyses.map((analysis) => (
                      <div key={analysis.id} className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">
                            {analysis.countries?.name} FY {analysis.fiscal_year}
                          </span>
                          <Badge variant="secondary">Completed</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {analysis.ai_summary ? 
                            analysis.ai_summary.substring(0, 120) + '...' :
                            'Budget analysis completed successfully'
                          }
                        </p>
                        <div className="mt-2 text-xs text-muted-foreground">
                          {analysis.processed_at && new Date(analysis.processed_at).toLocaleDateString()}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-muted-foreground py-8">
                      No recent analyses. Upload a budget document to get started.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SovereignDashboard;