import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Play, CheckCircle, AlertCircle } from 'lucide-react';

export function InitializeData() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleInitialize = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      console.log('Calling initialize-data function...');
      const { data, error } = await supabase.functions.invoke('initialize-data', {
        body: {}
      });

      if (error) {
        console.error('Function error:', error);
        setError(error.message || 'Unknown error occurred');
      } else {
        console.log('Function response:', data);
        setResult(data);
      }
    } catch (err) {
      console.error('Exception calling function:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleTestDataIngestion = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      console.log('Calling data-ingestion function with treasury action...');
      const { data, error } = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'treasury' }
      });

      if (error) {
        console.error('Function error:', error);
        setError(error.message || 'Unknown error occurred');
      } else {
        console.log('Function response:', data);
        setResult(data);
      }
    } catch (err) {
      console.error('Exception calling function:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Play className="h-5 w-5" />
          Initialize Data
        </CardTitle>
        <CardDescription>
          Load fresh data from FRED API, World Bank, and generate ESG scores
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Button 
            onClick={handleInitialize} 
            disabled={loading}
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Initializing...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Initialize All Data
              </>
            )}
          </Button>
          
          <Button 
            onClick={handleTestDataIngestion} 
            disabled={loading}
            variant="outline"
            className="w-full"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Test Treasury Data Ingestion
              </>
            )}
          </Button>
        </div>

        {error && (
          <div className="flex items-center gap-2 p-3 bg-destructive/10 text-destructive rounded-lg">
            <AlertCircle className="h-4 w-4" />
            <span className="text-sm">{error}</span>
          </div>
        )}

        {result && (
          <div className="flex items-center gap-2 p-3 bg-primary/10 text-primary rounded-lg">
            <CheckCircle className="h-4 w-4" />
            <span className="text-sm">
              Data initialized successfully! Check the dashboard for updates.
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}