export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      agent_passport: {
        Row: {
          agent_id: string
          certifications: string[] | null
          created_at: string
          jurisdiction: Database["public"]["Enums"]["jurisdiction"]
          last_audit_at: string | null
          passport_id: string
          risk_tier: Database["public"]["Enums"]["risk_tier"]
          status: Database["public"]["Enums"]["passport_status"]
        }
        Insert: {
          agent_id: string
          certifications?: string[] | null
          created_at?: string
          jurisdiction?: Database["public"]["Enums"]["jurisdiction"]
          last_audit_at?: string | null
          passport_id?: string
          risk_tier?: Database["public"]["Enums"]["risk_tier"]
          status?: Database["public"]["Enums"]["passport_status"]
        }
        Update: {
          agent_id?: string
          certifications?: string[] | null
          created_at?: string
          jurisdiction?: Database["public"]["Enums"]["jurisdiction"]
          last_audit_at?: string | null
          passport_id?: string
          risk_tier?: Database["public"]["Enums"]["risk_tier"]
          status?: Database["public"]["Enums"]["passport_status"]
        }
        Relationships: [
          {
            foreignKeyName: "agent_passport_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agent_registry"
            referencedColumns: ["agent_id"]
          },
        ]
      }
      agent_registry: {
        Row: {
          agent_id: string
          created_at: string
          description: string | null
          model_type: string
          name: string
          owner_id: string
        }
        Insert: {
          agent_id?: string
          created_at?: string
          description?: string | null
          model_type: string
          name: string
          owner_id: string
        }
        Update: {
          agent_id?: string
          created_at?: string
          description?: string | null
          model_type?: string
          name?: string
          owner_id?: string
        }
        Relationships: []
      }
      ai_interactions: {
        Row: {
          created_at: string
          id: string
          language_code: string | null
          lesson_id: string | null
          question: string
          response: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          language_code?: string | null
          lesson_id?: string | null
          question: string
          response: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          language_code?: string | null
          lesson_id?: string | null
          question?: string
          response?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_interactions_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_model_runs: {
        Row: {
          confidence_score: number | null
          created_at: string | null
          execution_time_ms: number | null
          id: string
          input_data: Json | null
          model_type: string
          model_version: string | null
          output_data: Json | null
        }
        Insert: {
          confidence_score?: number | null
          created_at?: string | null
          execution_time_ms?: number | null
          id?: string
          input_data?: Json | null
          model_type: string
          model_version?: string | null
          output_data?: Json | null
        }
        Update: {
          confidence_score?: number | null
          created_at?: string | null
          execution_time_ms?: number | null
          id?: string
          input_data?: Json | null
          model_type?: string
          model_version?: string | null
          output_data?: Json | null
        }
        Relationships: []
      }
      api_requests: {
        Row: {
          created_at: string | null
          endpoint: string
          execution_time_ms: number | null
          id: string
          request_method: string | null
          request_params: Json | null
          response_status: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          endpoint: string
          execution_time_ms?: number | null
          id?: string
          request_method?: string | null
          request_params?: Json | null
          response_status?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          endpoint?: string
          execution_time_ms?: number | null
          id?: string
          request_method?: string | null
          request_params?: Json | null
          response_status?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      badges: {
        Row: {
          category: string
          created_at: string
          description: string
          icon_url: string | null
          id: string
          name: string
        }
        Insert: {
          category?: string
          created_at?: string
          description: string
          icon_url?: string | null
          id?: string
          name: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string
          icon_url?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      call_log: {
        Row: {
          agent_id: string
          call_hash: string
          input_text: string
          log_id: string
          output_text: string
          timestamp: string
          tool_used: string | null
        }
        Insert: {
          agent_id: string
          call_hash: string
          input_text: string
          log_id?: string
          output_text: string
          timestamp?: string
          tool_used?: string | null
        }
        Update: {
          agent_id?: string
          call_hash?: string
          input_text?: string
          log_id?: string
          output_text?: string
          timestamp?: string
          tool_used?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "call_log_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agent_registry"
            referencedColumns: ["agent_id"]
          },
        ]
      }
      certify_log: {
        Row: {
          agent_id: string
          badge_score: number
          badge_url: string | null
          certify_id: string
          compliance_level: Database["public"]["Enums"]["compliance_level"]
          created_at: string
        }
        Insert: {
          agent_id: string
          badge_score?: number
          badge_url?: string | null
          certify_id?: string
          compliance_level?: Database["public"]["Enums"]["compliance_level"]
          created_at?: string
        }
        Update: {
          agent_id?: string
          badge_score?: number
          badge_url?: string | null
          certify_id?: string
          compliance_level?: Database["public"]["Enums"]["compliance_level"]
          created_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "certify_log_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agent_registry"
            referencedColumns: ["agent_id"]
          },
        ]
      }
      countries: {
        Row: {
          created_at: string | null
          gdp_usd: number | null
          id: string
          income_level: string | null
          iso_code: string
          name: string
          population: number | null
          region: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          gdp_usd?: number | null
          id?: string
          income_level?: string | null
          iso_code: string
          name: string
          population?: number | null
          region?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          gdp_usd?: number | null
          id?: string
          income_level?: string | null
          iso_code?: string
          name?: string
          population?: number | null
          region?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      course_translations: {
        Row: {
          course_id: string
          created_at: string
          description: string
          id: string
          language_code: string
          title: string
        }
        Insert: {
          course_id: string
          created_at?: string
          description: string
          id?: string
          language_code?: string
          title: string
        }
        Update: {
          course_id?: string
          created_at?: string
          description?: string
          id?: string
          language_code?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_translations_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          age_group: string
          created_at: string
          description: string
          id: string
          level: string
          slug: string
          thumbnail_url: string | null
          title: string
          updated_at: string
        }
        Insert: {
          age_group: string
          created_at?: string
          description: string
          id?: string
          level: string
          slug: string
          thumbnail_url?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          age_group?: string
          created_at?: string
          description?: string
          id?: string
          level?: string
          slug?: string
          thumbnail_url?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      esg_scores: {
        Row: {
          assessment_date: string
          country_id: string | null
          created_at: string | null
          debt_sustainability_score: number | null
          environmental_score: number | null
          fiscal_transparency_score: number | null
          governance_score: number | null
          id: string
          methodology_version: string | null
          overall_score: number | null
          sdg_alignment: Json | null
          social_score: number | null
        }
        Insert: {
          assessment_date: string
          country_id?: string | null
          created_at?: string | null
          debt_sustainability_score?: number | null
          environmental_score?: number | null
          fiscal_transparency_score?: number | null
          governance_score?: number | null
          id?: string
          methodology_version?: string | null
          overall_score?: number | null
          sdg_alignment?: Json | null
          social_score?: number | null
        }
        Update: {
          assessment_date?: string
          country_id?: string | null
          created_at?: string | null
          debt_sustainability_score?: number | null
          environmental_score?: number | null
          fiscal_transparency_score?: number | null
          governance_score?: number | null
          id?: string
          methodology_version?: string | null
          overall_score?: number | null
          sdg_alignment?: Json | null
          social_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "esg_scores_country_id_fkey"
            columns: ["country_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
        ]
      }
      fed_meetings: {
        Row: {
          ai_summary: string | null
          created_at: string | null
          decision_magnitude: number | null
          fed_funds_rate: number | null
          hawkish_dovish_score: number | null
          id: string
          meeting_date: string
          meeting_minutes_text: string | null
          rate_decision: string | null
        }
        Insert: {
          ai_summary?: string | null
          created_at?: string | null
          decision_magnitude?: number | null
          fed_funds_rate?: number | null
          hawkish_dovish_score?: number | null
          id?: string
          meeting_date: string
          meeting_minutes_text?: string | null
          rate_decision?: string | null
        }
        Update: {
          ai_summary?: string | null
          created_at?: string | null
          decision_magnitude?: number | null
          fed_funds_rate?: number | null
          hawkish_dovish_score?: number | null
          id?: string
          meeting_date?: string
          meeting_minutes_text?: string | null
          rate_decision?: string | null
        }
        Relationships: []
      }
      government_budgets: {
        Row: {
          ai_summary: string | null
          budget_balance: number | null
          country_id: string | null
          created_at: string | null
          currency: string
          document_url: string | null
          esg_analysis: Json | null
          fiscal_year: number
          id: string
          pdf_text: string | null
          primary_balance: number | null
          processed_at: string | null
          total_expenditure: number | null
          total_revenue: number | null
        }
        Insert: {
          ai_summary?: string | null
          budget_balance?: number | null
          country_id?: string | null
          created_at?: string | null
          currency: string
          document_url?: string | null
          esg_analysis?: Json | null
          fiscal_year: number
          id?: string
          pdf_text?: string | null
          primary_balance?: number | null
          processed_at?: string | null
          total_expenditure?: number | null
          total_revenue?: number | null
        }
        Update: {
          ai_summary?: string | null
          budget_balance?: number | null
          country_id?: string | null
          created_at?: string | null
          currency?: string
          document_url?: string | null
          esg_analysis?: Json | null
          fiscal_year?: number
          id?: string
          pdf_text?: string | null
          primary_balance?: number | null
          processed_at?: string | null
          total_expenditure?: number | null
          total_revenue?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "government_budgets_country_id_fkey"
            columns: ["country_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
        ]
      }
      institutional_flows: {
        Row: {
          ai_analysis: string | null
          anomaly_score: number | null
          created_at: string | null
          date: string
          direction: string | null
          flow_type: string | null
          id: string
          security_type: string | null
          volume_usd: number | null
        }
        Insert: {
          ai_analysis?: string | null
          anomaly_score?: number | null
          created_at?: string | null
          date: string
          direction?: string | null
          flow_type?: string | null
          id?: string
          security_type?: string | null
          volume_usd?: number | null
        }
        Update: {
          ai_analysis?: string | null
          anomaly_score?: number | null
          created_at?: string | null
          date?: string
          direction?: string | null
          flow_type?: string | null
          id?: string
          security_type?: string | null
          volume_usd?: number | null
        }
        Relationships: []
      }
      lesson_translations: {
        Row: {
          content_markdown: string
          created_at: string
          id: string
          language_code: string
          lesson_id: string
          title: string
        }
        Insert: {
          content_markdown: string
          created_at?: string
          id?: string
          language_code?: string
          lesson_id: string
          title: string
        }
        Update: {
          content_markdown?: string
          created_at?: string
          id?: string
          language_code?: string
          lesson_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "lesson_translations_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
        ]
      }
      lessons: {
        Row: {
          content_markdown: string
          course_id: string
          created_at: string
          id: string
          lesson_number: number
          title: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          content_markdown: string
          course_id: string
          created_at?: string
          id?: string
          lesson_number: number
          title: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          content_markdown?: string
          course_id?: string
          created_at?: string
          id?: string
          lesson_number?: number
          title?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lessons_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      parent_emails: {
        Row: {
          child_id: string
          created_at: string
          email: string
          id: string
          is_active: boolean | null
          parent_id: string
        }
        Insert: {
          child_id: string
          created_at?: string
          email: string
          id?: string
          is_active?: boolean | null
          parent_id: string
        }
        Update: {
          child_id?: string
          created_at?: string
          email?: string
          id?: string
          is_active?: boolean | null
          parent_id?: string
        }
        Relationships: []
      }
      policy_trigger_log: {
        Row: {
          agent_id: string
          input_text: string
          status: Database["public"]["Enums"]["trigger_status"]
          trigger_id: string
          trigger_type: Database["public"]["Enums"]["trigger_type"]
          triggered_at: string
        }
        Insert: {
          agent_id: string
          input_text: string
          status?: Database["public"]["Enums"]["trigger_status"]
          trigger_id?: string
          trigger_type: Database["public"]["Enums"]["trigger_type"]
          triggered_at?: string
        }
        Update: {
          agent_id?: string
          input_text?: string
          status?: Database["public"]["Enums"]["trigger_status"]
          trigger_id?: string
          trigger_type?: Database["public"]["Enums"]["trigger_type"]
          triggered_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "policy_trigger_log_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agent_registry"
            referencedColumns: ["agent_id"]
          },
        ]
      }
      premium_access: {
        Row: {
          course_id: string | null
          created_at: string
          id: string
          plan_type: string
          stripe_subscription_id: string | null
          updated_at: string
          user_id: string
          valid_until: string | null
        }
        Insert: {
          course_id?: string | null
          created_at?: string
          id?: string
          plan_type?: string
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id: string
          valid_until?: string | null
        }
        Update: {
          course_id?: string | null
          created_at?: string
          id?: string
          plan_type?: string
          stripe_subscription_id?: string | null
          updated_at?: string
          user_id?: string
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "premium_access_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          api_calls_remaining: number | null
          api_key: string | null
          child_id: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          is_active: boolean | null
          organization_name: string | null
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          api_calls_remaining?: number | null
          api_key?: string | null
          child_id?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id?: string
          is_active?: boolean | null
          organization_name?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          api_calls_remaining?: number | null
          api_key?: string | null
          child_id?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          is_active?: boolean | null
          organization_name?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      progress: {
        Row: {
          completed_at: string | null
          course_id: string
          created_at: string
          id: string
          lesson_id: string | null
          score: number | null
          status: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          course_id: string
          created_at?: string
          id?: string
          lesson_id?: string | null
          score?: number | null
          status?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          course_id?: string
          created_at?: string
          id?: string
          lesson_id?: string | null
          score?: number | null
          status?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "progress_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "progress_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
        ]
      }
      quizzes: {
        Row: {
          correct_answer: number
          created_at: string
          id: string
          lesson_id: string
          options: string[]
          question: string
        }
        Insert: {
          correct_answer: number
          created_at?: string
          id?: string
          lesson_id: string
          options: string[]
          question: string
        }
        Update: {
          correct_answer?: number
          created_at?: string
          id?: string
          lesson_id?: string
          options?: string[]
          question?: string
        }
        Relationships: [
          {
            foreignKeyName: "quizzes_lesson_id_fkey"
            columns: ["lesson_id"]
            isOneToOne: false
            referencedRelation: "lessons"
            referencedColumns: ["id"]
          },
        ]
      }
      sovereign_debt: {
        Row: {
          country_id: string | null
          created_at: string | null
          currency_composition: Json | null
          debt_service_ratio: number | null
          debt_to_gdp: number | null
          domestic_debt_usd: number | null
          external_debt_usd: number | null
          id: string
          maturity_profile: Json | null
          year: number
        }
        Insert: {
          country_id?: string | null
          created_at?: string | null
          currency_composition?: Json | null
          debt_service_ratio?: number | null
          debt_to_gdp?: number | null
          domestic_debt_usd?: number | null
          external_debt_usd?: number | null
          id?: string
          maturity_profile?: Json | null
          year: number
        }
        Update: {
          country_id?: string | null
          created_at?: string | null
          currency_composition?: Json | null
          debt_service_ratio?: number | null
          debt_to_gdp?: number | null
          domestic_debt_usd?: number | null
          external_debt_usd?: number | null
          id?: string
          maturity_profile?: Json | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "sovereign_debt_country_id_fkey"
            columns: ["country_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
        ]
      }
      treasury_yields: {
        Row: {
          created_at: string | null
          date: string
          id: string
          maturity: string
          source: string | null
          yield_rate: number
        }
        Insert: {
          created_at?: string | null
          date: string
          id?: string
          maturity: string
          source?: string | null
          yield_rate: number
        }
        Update: {
          created_at?: string | null
          date?: string
          id?: string
          maturity?: string
          source?: string | null
          yield_rate?: number
        }
        Relationships: []
      }
      user_badges: {
        Row: {
          badge_id: string
          earned_at: string
          id: string
          user_id: string
        }
        Insert: {
          badge_id: string
          earned_at?: string
          id?: string
          user_id: string
        }
        Update: {
          badge_id?: string
          earned_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_badges_badge_id_fkey"
            columns: ["badge_id"]
            isOneToOne: false
            referencedRelation: "badges"
            referencedColumns: ["id"]
          },
        ]
      }
      user_stats: {
        Row: {
          ai_questions_asked: number | null
          courses_completed: number | null
          created_at: string
          id: string
          lessons_completed: number | null
          perfect_scores: number | null
          quizzes_completed: number | null
          total_score: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          ai_questions_asked?: number | null
          courses_completed?: number | null
          created_at?: string
          id?: string
          lessons_completed?: number | null
          perfect_scores?: number | null
          quizzes_completed?: number | null
          total_score?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          ai_questions_asked?: number | null
          courses_completed?: number | null
          created_at?: string
          id?: string
          lessons_completed?: number | null
          perfect_scores?: number | null
          quizzes_completed?: number | null
          total_score?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      yield_predictions: {
        Row: {
          actual_yield: number | null
          confidence_interval_lower: number | null
          confidence_interval_upper: number | null
          created_at: string | null
          id: string
          maturity: string
          model_version: string | null
          predicted_yield: number
          prediction_date: string
          target_date: string
        }
        Insert: {
          actual_yield?: number | null
          confidence_interval_lower?: number | null
          confidence_interval_upper?: number | null
          created_at?: string | null
          id?: string
          maturity: string
          model_version?: string | null
          predicted_yield: number
          prediction_date: string
          target_date: string
        }
        Update: {
          actual_yield?: number | null
          confidence_interval_lower?: number | null
          confidence_interval_upper?: number | null
          created_at?: string | null
          id?: string
          maturity?: string
          model_version?: string | null
          predicted_yield?: number
          prediction_date?: string
          target_date?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      award_badge: {
        Args: { p_user_id: string; p_badge_name: string }
        Returns: boolean
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: Database["public"]["Enums"]["app_role"]
      }
      update_user_stats: {
        Args: {
          p_user_id: string
          p_courses_completed?: number
          p_lessons_completed?: number
          p_quizzes_completed?: number
          p_perfect_scores?: number
          p_ai_questions_asked?: number
          p_score_to_add?: number
        }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "learner" | "parent" | "instructor"
      compliance_level: "basic" | "partial" | "full"
      jurisdiction: "EU" | "US" | "global"
      passport_status: "draft" | "certified" | "revoked"
      risk_tier: "low" | "med" | "high"
      trigger_status: "flagged" | "dismissed" | "blocked"
      trigger_type: "hallucination" | "misuse" | "pii_leak"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["learner", "parent", "instructor"],
      compliance_level: ["basic", "partial", "full"],
      jurisdiction: ["EU", "US", "global"],
      passport_status: ["draft", "certified", "revoked"],
      risk_tier: ["low", "med", "high"],
      trigger_status: ["flagged", "dismissed", "blocked"],
      trigger_type: ["hallucination", "misuse", "pii_leak"],
    },
  },
} as const
