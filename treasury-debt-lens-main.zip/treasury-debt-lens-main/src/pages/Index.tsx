import React, { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import DashboardLayout from '@/components/dashboard/DashboardLayout';
import TreasuryDashboard from '@/components/dashboard/TreasuryDashboard';
import SovereignDashboard from '@/components/dashboard/SovereignDashboard';
import AIInsightsDashboard from '@/components/dashboard/AIInsightsDashboard';
import { Button } from '@/components/ui/button';
import { TrendingUp, ArrowRight } from 'lucide-react';
import { InitializeData } from '@/components/InitializeData';

const Index = () => {
  const { user, loading } = useAuth();
  const [activeSection, setActiveSection] = useState('treasury');

  // Redirect to auth if not authenticated
  useEffect(() => {
    if (!loading && !user) {
      window.location.href = '/auth';
    }
  }, [user, loading]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted">
        <div className="text-center space-y-6 max-w-md">
          <div className="flex items-center justify-center gap-3">
            <TrendingUp className="h-12 w-12 text-primary" />
            <h1 className="text-3xl font-bold">TreasuryMarketCap</h1>
          </div>
          <p className="text-xl text-muted-foreground">
            AI-Driven Treasury & Sovereign Finance Intelligence Platform
          </p>
          <Button onClick={() => window.location.href = '/auth'} size="lg" className="gap-2">
            Access Platform <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  }

  const renderDashboardContent = () => {
    switch (activeSection) {
      case 'treasury':
        return <TreasuryDashboard />;
      case 'sovereign':
        return <SovereignDashboard />;
      case 'ai-insights':
        return <AIInsightsDashboard />;
      case 'api':
        return (
          <div className="p-6">
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="text-center space-y-4">
                <h1 className="text-3xl font-bold">TreasuryMarketCap API</h1>
                <p className="text-xl text-muted-foreground">
                  Production-ready REST API for financial intelligence
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 border rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">Treasury Data</h3>
                  <code className="text-sm bg-muted p-2 rounded block">
                    GET /treasury-yields?maturity=10Y&limit=100
                  </code>
                  <p className="text-sm text-muted-foreground mt-2">
                    Access real-time Treasury yield data with filtering options
                  </p>
                </div>
                
                <div className="p-6 border rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">Sovereign Debt</h3>
                  <code className="text-sm bg-muted p-2 rounded block">
                    GET /sovereign-debt?country=USA&year=2024
                  </code>
                  <p className="text-sm text-muted-foreground mt-2">
                    Global sovereign debt metrics and analytics
                  </p>
                </div>
                
                <div className="p-6 border rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">AI Predictions</h3>
                  <code className="text-sm bg-muted p-2 rounded block">
                    GET /yield-predictions?maturity=10Y
                  </code>
                  <p className="text-sm text-muted-foreground mt-2">
                    AI-powered yield forecasts with confidence intervals
                  </p>
                </div>
                
                <div className="p-6 border rounded-lg">
                  <h3 className="text-lg font-semibold mb-3">ESG Scores</h3>
                  <code className="text-sm bg-muted p-2 rounded block">
                    GET /esg-scores?country=DEU
                  </code>
                  <p className="text-sm text-muted-foreground mt-2">
                    Environmental, Social, and Governance metrics
                  </p>
                </div>
              </div>
              
              <div className="p-6 bg-muted rounded-lg">
                <h3 className="text-lg font-semibold mb-3">Authentication</h3>
                <p className="text-sm mb-2">Include your API key in the request headers:</p>
                <code className="text-sm bg-background p-2 rounded block">
                  X-API-Key: your_api_key_here
                </code>
              </div>
            </div>
          </div>
        );
      case 'settings':
        return (
          <div className="p-6">
            <div className="max-w-2xl mx-auto space-y-6">
              <div className="text-center space-y-4">
                <h1 className="text-3xl font-bold">Account Settings</h1>
                <p className="text-xl text-muted-foreground">
                  Manage your account and initialize data
                </p>
              </div>
              
              <div className="flex justify-center">
                <InitializeData />
              </div>
              
              <div className="text-center text-muted-foreground">
                <p>Additional profile management features coming soon...</p>
              </div>
            </div>
          </div>
        );
      default:
        return <TreasuryDashboard />;
    }
  };

  return (
    <DashboardLayout activeSection={activeSection} onSectionChange={setActiveSection}>
      {renderDashboardContent()}
    </DashboardLayout>
  );
};

export default Index;
