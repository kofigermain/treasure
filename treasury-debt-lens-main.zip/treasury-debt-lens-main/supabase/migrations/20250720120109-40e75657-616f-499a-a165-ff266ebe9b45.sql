-- Create enum types
CREATE TYPE app_role AS ENUM ('learner', 'instructor', 'parent', 'admin', 'basic', 'professional', 'enterprise', 'institutional', 'government');
CREATE TYPE subscription_tier AS ENUM ('basic', 'professional', 'enterprise', 'institutional', 'government');
CREATE TYPE rate_decision AS ENUM ('increase', 'decrease', 'hold');
CREATE TYPE flow_type AS ENUM ('foreign_central_bank', 'pension_fund', 'insurance', 'hedge_fund', 'sovereign_wealth');
CREATE TYPE direction AS ENUM ('buy', 'sell');

-- Core entity tables
CREATE TABLE public.countries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  iso_code TEXT UNIQUE NOT NULL,
  region TEXT,
  income_level TEXT,
  population BIGINT,
  gdp_usd DECIMAL(15,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Update users table to include treasury platform fields
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS subscription_tier subscription_tier DEFAULT 'basic';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS organization_name TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS api_key TEXT UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex');
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS api_calls_remaining INTEGER DEFAULT 1000;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- US Treasury data tables
CREATE TABLE public.treasury_yields (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  maturity TEXT NOT NULL, -- '1M', '3M', '6M', '1Y', '2Y', '3Y', '5Y', '7Y', '10Y', '20Y', '30Y'
  yield_rate DECIMAL(6,4) NOT NULL,
  source TEXT DEFAULT 'FRED',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.fed_meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_date DATE NOT NULL,
  fed_funds_rate DECIMAL(6,4),
  rate_decision rate_decision,
  decision_magnitude DECIMAL(4,2), -- basis points
  meeting_minutes_text TEXT,
  hawkish_dovish_score DECIMAL(3,2), -- -1 to 1 scale
  ai_summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.yield_predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prediction_date DATE NOT NULL,
  target_date DATE NOT NULL,
  maturity TEXT NOT NULL,
  predicted_yield DECIMAL(6,4) NOT NULL,
  confidence_interval_lower DECIMAL(6,4),
  confidence_interval_upper DECIMAL(6,4),
  model_version TEXT,
  actual_yield DECIMAL(6,4), -- filled in later for backtesting
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.institutional_flows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  flow_type flow_type,
  security_type TEXT,
  volume_usd DECIMAL(15,2),
  direction direction,
  anomaly_score DECIMAL(4,2), -- 0-1 scale
  ai_analysis TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Global sovereign debt tables
CREATE TABLE public.sovereign_debt (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  year INTEGER NOT NULL,
  debt_to_gdp DECIMAL(6,2),
  external_debt_usd DECIMAL(15,2),
  domestic_debt_usd DECIMAL(15,2),
  debt_service_ratio DECIMAL(6,2),
  currency_composition JSONB, -- {"USD": 45.2, "EUR": 30.1, "Local": 24.7}
  maturity_profile JSONB, -- {"short_term": 25.3, "medium_term": 40.2, "long_term": 34.5}
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.government_budgets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  fiscal_year INTEGER NOT NULL,
  currency TEXT NOT NULL,
  total_revenue DECIMAL(15,2),
  total_expenditure DECIMAL(15,2),
  budget_balance DECIMAL(15,2),
  primary_balance DECIMAL(15,2),
  document_url TEXT,
  pdf_text TEXT,
  ai_summary TEXT,
  esg_analysis JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  processed_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE public.esg_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  assessment_date DATE NOT NULL,
  environmental_score DECIMAL(4,2), -- 0-100 scale
  social_score DECIMAL(4,2),
  governance_score DECIMAL(4,2),
  overall_score DECIMAL(4,2),
  sdg_alignment JSONB, -- {"SDG1": 75.2, "SDG7": 60.1, "SDG13": 45.8}
  fiscal_transparency_score DECIMAL(4,2),
  debt_sustainability_score DECIMAL(4,2),
  methodology_version TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.ai_model_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model_type TEXT NOT NULL, -- 'yield_forecasting', 'fed_prediction', 'esg_classification', etc.
  input_data JSONB,
  output_data JSONB,
  model_version TEXT,
  confidence_score DECIMAL(4,2),
  execution_time_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- API usage tracking
CREATE TABLE public.api_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  endpoint TEXT NOT NULL,
  request_method TEXT,
  request_params JSONB,
  response_status INTEGER,
  execution_time_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX idx_treasury_yields_date_maturity ON public.treasury_yields(date, maturity);
CREATE INDEX idx_yield_predictions_dates ON public.yield_predictions(prediction_date, target_date);
CREATE INDEX idx_sovereign_debt_country_year ON public.sovereign_debt(country_id, year);
CREATE INDEX idx_esg_scores_country_date ON public.esg_scores(country_id, assessment_date);
CREATE INDEX idx_api_requests_user_created ON public.api_requests(user_id, created_at);

-- Enable RLS
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.treasury_yields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fed_meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.yield_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.institutional_flows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sovereign_debt ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.government_budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.esg_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_model_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.api_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Public read access for reference data
CREATE POLICY "Anyone can view countries" ON public.countries FOR SELECT USING (true);
CREATE POLICY "Anyone can view treasury yields" ON public.treasury_yields FOR SELECT USING (true);
CREATE POLICY "Anyone can view fed meetings" ON public.fed_meetings FOR SELECT USING (true);
CREATE POLICY "Anyone can view sovereign debt" ON public.sovereign_debt FOR SELECT USING (true);
CREATE POLICY "Anyone can view esg scores" ON public.esg_scores FOR SELECT USING (true);

-- Subscription-based access for predictions and analysis
CREATE POLICY "Users can view yield predictions" ON public.yield_predictions FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND subscription_tier IN ('professional', 'enterprise', 'institutional', 'government')
  )
);

CREATE POLICY "Users can view institutional flows" ON public.institutional_flows FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND subscription_tier IN ('enterprise', 'institutional', 'government')
  )
);

CREATE POLICY "Users can view government budgets" ON public.government_budgets FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND subscription_tier IN ('professional', 'enterprise', 'institutional', 'government')
  )
);

-- API usage policies
CREATE POLICY "Users can view own API requests" ON public.api_requests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "System can create API requests" ON public.api_requests FOR INSERT WITH CHECK (true);

-- AI model access
CREATE POLICY "Users can view AI models" ON public.ai_model_runs FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = auth.uid() 
    AND subscription_tier IN ('professional', 'enterprise', 'institutional', 'government')
  )
);

-- Insert sample data
INSERT INTO public.countries (name, iso_code, region, income_level, population, gdp_usd) VALUES
('United States', 'USA', 'North America', 'High income', 331900000, 21430000000000.00),
('Germany', 'DEU', 'Europe', 'High income', 83200000, 3860000000000.00),
('Japan', 'JPN', 'Asia', 'High income', 125800000, 4940000000000.00),
('United Kingdom', 'GBR', 'Europe', 'High income', 67900000, 2830000000000.00),
('France', 'FRA', 'Europe', 'High income', 67400000, 2640000000000.00);

-- Sample treasury yield data
INSERT INTO public.treasury_yields (date, maturity, yield_rate, source) VALUES
('2024-01-15', '10Y', 4.2500, 'FRED'),
('2024-01-15', '2Y', 4.1800, 'FRED'),
('2024-01-15', '30Y', 4.4200, 'FRED'),
('2024-01-16', '10Y', 4.2800, 'FRED'),
('2024-01-16', '2Y', 4.2100, 'FRED'),
('2024-01-16', '30Y', 4.4500, 'FRED');

-- Update timestamps trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_countries_updated_at
  BEFORE UPDATE ON public.countries
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();