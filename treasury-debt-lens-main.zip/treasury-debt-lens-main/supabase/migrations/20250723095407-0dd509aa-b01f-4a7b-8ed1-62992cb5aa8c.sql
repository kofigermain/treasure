-- Fix RLS policies for data visibility

-- Treasury yields - allow anyone to read
CREATE POLICY "Anyone can view treasury yields" ON treasury_yields FOR SELECT USING (true);

-- Fed meetings - allow anyone to read
CREATE POLICY "Anyone can view fed meetings" ON fed_meetings FOR SELECT USING (true);

-- Yield predictions - allow system to insert and anyone to read
CREATE POLICY "Anyone can view yield predictions" ON yield_predictions FOR SELECT USING (true);
CREATE POLICY "System can create yield predictions" ON yield_predictions FOR INSERT WITH CHECK (true);
CREATE POLICY "System can update yield predictions" ON yield_predictions FOR UPDATE USING (true);

-- Institutional flows - allow system to insert and anyone to read
CREATE POLICY "Anyone can view institutional flows" ON institutional_flows FOR SELECT USING (true);
CREATE POLICY "System can create institutional flows" ON institutional_flows FOR INSERT WITH CHECK (true);

-- Government budgets - allow system to insert and anyone to read
CREATE POLICY "Anyone can view government budgets" ON government_budgets FOR SELECT USING (true);
CREATE POLICY "System can create government budgets" ON government_budgets FOR INSERT WITH CHECK (true);
CREATE POLICY "System can update government budgets" ON government_budgets FOR UPDATE USING (true);

-- AI model runs - allow system to insert and anyone to read
CREATE POLICY "Anyone can view ai model runs" ON ai_model_runs FOR SELECT USING (true);
CREATE POLICY "System can create ai model runs" ON ai_model_runs FOR INSERT WITH CHECK (true);