-- Fix RLS policies to allow public reading of data for dashboard display

-- Allow public reading of yield predictions
DROP POLICY IF EXISTS "Anyone can view yield predictions" ON yield_predictions;
CREATE POLICY "Anyone can view yield predictions" 
ON yield_predictions FOR SELECT 
USING (true);

-- Allow public reading of ai model runs  
DROP POLICY IF EXISTS "Anyone can view ai model runs" ON ai_model_runs;
CREATE POLICY "Anyone can view ai model runs" 
ON ai_model_runs FOR SELECT 
USING (true);

-- Allow public reading of institutional flows
DROP POLICY IF EXISTS "Anyone can view institutional flows" ON institutional_flows;
CREATE POLICY "Anyone can view institutional flows" 
ON institutional_flows FOR SELECT 
USING (true);

-- Allow public reading of government budgets
DROP POLICY IF EXISTS "Anyone can view government budgets" ON government_budgets;
CREATE POLICY "Anyone can view government budgets" 
ON government_budgets FOR SELECT 
USING (true);