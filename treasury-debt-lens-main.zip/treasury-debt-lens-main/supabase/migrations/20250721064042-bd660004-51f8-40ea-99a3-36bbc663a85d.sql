-- Core entity tables
CREATE TABLE public.countries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  iso_code TEXT UNIQUE NOT NULL,
  region TEXT,
  income_level TEXT,
  population BIGINT,
  gdp_usd BIGINT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Update profiles table to include treasury platform fields
ALTER TABLE public.profiles ADD COLUMN organization_name TEXT;
ALTER TABLE public.profiles ADD COLUMN api_key TEXT UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex');
ALTER TABLE public.profiles ADD COLUMN api_calls_remaining INTEGER DEFAULT 1000;
ALTER TABLE public.profiles ADD COLUMN is_active BOOLEAN DEFAULT TRUE;

-- US Treasury data tables
CREATE TABLE public.treasury_yields (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  maturity TEXT NOT NULL,
  yield_rate DECIMAL(6,4) NOT NULL,
  source TEXT DEFAULT 'FRED',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.fed_meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  meeting_date DATE NOT NULL,
  fed_funds_rate DECIMAL(6,4),
  rate_decision TEXT CHECK (rate_decision IN ('increase', 'decrease', 'hold')),
  decision_magnitude DECIMAL(4,2),
  meeting_minutes_text TEXT,
  hawkish_dovish_score DECIMAL(3,2),
  ai_summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.yield_predictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prediction_date DATE NOT NULL,
  target_date DATE NOT NULL,
  maturity TEXT NOT NULL,
  predicted_yield DECIMAL(6,4) NOT NULL,
  confidence_interval_lower DECIMAL(6,4),
  confidence_interval_upper DECIMAL(6,4),
  model_version TEXT,
  actual_yield DECIMAL(6,4),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.institutional_flows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  flow_type TEXT CHECK (flow_type IN ('foreign_central_bank', 'pension_fund', 'insurance', 'hedge_fund', 'sovereign_wealth')),
  security_type TEXT,
  volume_usd BIGINT,
  direction TEXT CHECK (direction IN ('buy', 'sell')),
  anomaly_score DECIMAL(4,2),
  ai_analysis TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Global sovereign debt tables
CREATE TABLE public.sovereign_debt (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  year INTEGER NOT NULL,
  debt_to_gdp DECIMAL(6,2),
  external_debt_usd BIGINT,
  domestic_debt_usd BIGINT,
  debt_service_ratio DECIMAL(6,2),
  currency_composition JSONB,
  maturity_profile JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.government_budgets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  fiscal_year INTEGER NOT NULL,
  currency TEXT NOT NULL,
  total_revenue BIGINT,
  total_expenditure BIGINT,
  budget_balance BIGINT,
  primary_balance BIGINT,
  document_url TEXT,
  pdf_text TEXT,
  ai_summary TEXT,
  esg_analysis JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  processed_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE public.esg_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id UUID REFERENCES public.countries(id),
  assessment_date DATE NOT NULL,
  environmental_score DECIMAL(4,2),
  social_score DECIMAL(4,2),
  governance_score DECIMAL(4,2),
  overall_score DECIMAL(4,2),
  sdg_alignment JSONB,
  fiscal_transparency_score DECIMAL(4,2),
  debt_sustainability_score DECIMAL(4,2),
  methodology_version TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.ai_model_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model_type TEXT NOT NULL,
  input_data JSONB,
  output_data JSONB,
  model_version TEXT,
  confidence_score DECIMAL(4,2),
  execution_time_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE public.api_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id),
  endpoint TEXT NOT NULL,
  request_method TEXT,
  request_params JSONB,
  response_status INTEGER,
  execution_time_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX idx_treasury_yields_date_maturity ON public.treasury_yields(date, maturity);
CREATE INDEX idx_yield_predictions_dates ON public.yield_predictions(prediction_date, target_date);
CREATE INDEX idx_sovereign_debt_country_year ON public.sovereign_debt(country_id, year);
CREATE INDEX idx_esg_scores_country_date ON public.esg_scores(country_id, assessment_date);
CREATE INDEX idx_api_requests_user_created ON public.api_requests(user_id, created_at);

-- Enable RLS
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.treasury_yields ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fed_meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.yield_predictions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.institutional_flows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sovereign_debt ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.government_budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.esg_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_model_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.api_requests ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view countries" ON public.countries FOR SELECT USING (true);
CREATE POLICY "Anyone can view treasury yields" ON public.treasury_yields FOR SELECT USING (true);
CREATE POLICY "Anyone can view fed meetings" ON public.fed_meetings FOR SELECT USING (true);
CREATE POLICY "Anyone can view sovereign debt" ON public.sovereign_debt FOR SELECT USING (true);
CREATE POLICY "Anyone can view esg scores" ON public.esg_scores FOR SELECT USING (true);
CREATE POLICY "Users can view own API requests" ON public.api_requests FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "System can create API requests" ON public.api_requests FOR INSERT WITH CHECK (true);

-- Insert sample data (GDP in billions USD)
INSERT INTO public.countries (name, iso_code, region, income_level, population, gdp_usd) VALUES
('United States', 'USA', 'North America', 'High income', 331900000, 21430000000000),
('Germany', 'DEU', 'Europe', 'High income', 83200000, 3860000000000),
('Japan', 'JPN', 'Asia', 'High income', 125800000, 4940000000000),
('United Kingdom', 'GBR', 'Europe', 'High income', 67900000, 2830000000000),
('France', 'FRA', 'Europe', 'High income', 67400000, 2640000000000);

INSERT INTO public.treasury_yields (date, maturity, yield_rate, source) VALUES
('2024-01-15', '10Y', 4.2500, 'FRED'),
('2024-01-15', '2Y', 4.1800, 'FRED'),
('2024-01-15', '30Y', 4.4200, 'FRED'),
('2024-01-16', '10Y', 4.2800, 'FRED'),
('2024-01-16', '2Y', 4.2100, 'FRED'),
('2024-01-16', '30Y', 4.4500, 'FRED');