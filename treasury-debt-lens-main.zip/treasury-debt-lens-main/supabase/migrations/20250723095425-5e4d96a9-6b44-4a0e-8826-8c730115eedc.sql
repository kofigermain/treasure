-- Add missing RLS policies for data tables

-- Yield predictions policies
CREATE POLICY "System can create yield predictions" ON yield_predictions FOR INSERT WITH CHECK (true);
CREATE POLICY "System can update yield predictions" ON yield_predictions FOR UPDATE USING (true);

-- Institutional flows policies  
CREATE POLICY "System can create institutional flows" ON institutional_flows FOR INSERT WITH CHECK (true);

-- Government budgets policies
CREATE POLICY "System can create government budgets" ON government_budgets FOR INSERT WITH CHECK (true);
CREATE POLICY "System can update government budgets" ON government_budgets FOR UPDATE USING (true);

-- AI model runs policies
CREATE POLICY "System can create ai model runs" ON ai_model_runs FOR INSERT WITH CHECK (true);