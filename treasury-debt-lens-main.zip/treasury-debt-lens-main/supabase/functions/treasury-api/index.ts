import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-api-key',
};

interface AuthenticatedRequest extends Request {
  user?: any;
}

const authenticateRequest = async (req: Request): Promise<{ user: any; error?: string }> => {
  const apiKey = req.headers.get('X-API-Key');
  
  if (!apiKey) {
    return { user: null, error: 'API key required' };
  }

  const { data: user, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('api_key', apiKey)
    .eq('is_active', true)
    .single();

  if (error || !user) {
    return { user: null, error: 'Invalid API key' };
  }

  if (user.api_calls_remaining <= 0) {
    return { user: null, error: 'API quota exceeded' };
  }

  // Decrement API calls
  await supabase
    .from('profiles')
    .update({ api_calls_remaining: user.api_calls_remaining - 1 })
    .eq('id', user.id);

  return { user };
};

const logRequest = async (userId: string, endpoint: string, method: string, status: number, executionTime: number) => {
  await supabase.from('api_requests').insert({
    user_id: userId,
    endpoint,
    request_method: method,
    response_status: status,
    execution_time_ms: executionTime,
    created_at: new Date().toISOString()
  });
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  const url = new URL(req.url);
  const pathname = url.pathname;

  try {
    // Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    
    if (authError) {
      return new Response(JSON.stringify({ error: authError }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Route API requests
    if (pathname === '/treasury-yields') {
      return await handleTreasuryYields(req, user, startTime);
    } else if (pathname === '/sovereign-debt') {
      return await handleSovereignDebt(req, user, startTime);
    } else if (pathname === '/esg-scores') {
      return await handleESGScores(req, user, startTime);
    } else if (pathname === '/yield-predictions') {
      return await handleYieldPredictions(req, user, startTime);
    } else if (pathname === '/api-usage') {
      return await handleAPIUsage(req, user, startTime);
    } else {
      return new Response(JSON.stringify({ error: 'Endpoint not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

  } catch (error) {
    console.error('API error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

const handleTreasuryYields = async (req: Request, user: any, startTime: number) => {
  const url = new URL(req.url);
  const maturity = url.searchParams.get('maturity');
  const startDate = url.searchParams.get('start_date');
  const endDate = url.searchParams.get('end_date');
  const limit = parseInt(url.searchParams.get('limit') || '100');

  let query = supabase.from('treasury_yields').select('*');

  if (maturity) query = query.eq('maturity', maturity);
  if (startDate) query = query.gte('date', startDate);
  if (endDate) query = query.lte('date', endDate);

  const { data, error } = await query
    .order('date', { ascending: false })
    .limit(Math.min(limit, 1000));

  const executionTime = Date.now() - startTime;
  await logRequest(user.user_id, '/treasury-yields', 'GET', error ? 500 : 200, executionTime);

  if (error) throw error;

  return new Response(JSON.stringify({
    data,
    count: data?.length || 0,
    metadata: {
      endpoint: 'treasury-yields',
      execution_time_ms: executionTime
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
};

const handleSovereignDebt = async (req: Request, user: any, startTime: number) => {
  const url = new URL(req.url);
  const countryCode = url.searchParams.get('country');
  const year = url.searchParams.get('year');
  const limit = parseInt(url.searchParams.get('limit') || '100');

  let query = supabase
    .from('sovereign_debt')
    .select(`
      *,
      countries (name, iso_code, region, income_level)
    `);

  if (countryCode) {
    query = query.eq('countries.iso_code', countryCode);
  }
  if (year) {
    query = query.eq('year', parseInt(year));
  }

  const { data, error } = await query
    .order('year', { ascending: false })
    .limit(Math.min(limit, 1000));

  const executionTime = Date.now() - startTime;
  await logRequest(user.user_id, '/sovereign-debt', 'GET', error ? 500 : 200, executionTime);

  if (error) throw error;

  return new Response(JSON.stringify({
    data,
    count: data?.length || 0,
    metadata: {
      endpoint: 'sovereign-debt',
      execution_time_ms: executionTime
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
};

const handleESGScores = async (req: Request, user: any, startTime: number) => {
  // Check subscription tier for ESG access
  if (!['professional', 'enterprise', 'institutional', 'government'].includes(user.subscription_tier)) {
    return new Response(JSON.stringify({ 
      error: 'ESG scores require Professional tier or higher' 
    }), {
      status: 403,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const url = new URL(req.url);
  const countryCode = url.searchParams.get('country');
  const limit = parseInt(url.searchParams.get('limit') || '100');

  let query = supabase
    .from('esg_scores')
    .select(`
      *,
      countries (name, iso_code, region)
    `);

  if (countryCode) {
    query = query.eq('countries.iso_code', countryCode);
  }

  const { data, error } = await query
    .order('assessment_date', { ascending: false })
    .limit(Math.min(limit, 1000));

  const executionTime = Date.now() - startTime;
  await logRequest(user.user_id, '/esg-scores', 'GET', error ? 500 : 200, executionTime);

  if (error) throw error;

  return new Response(JSON.stringify({
    data,
    count: data?.length || 0,
    metadata: {
      endpoint: 'esg-scores',
      execution_time_ms: executionTime
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
};

const handleYieldPredictions = async (req: Request, user: any, startTime: number) => {
  // Check subscription tier for predictions
  if (!['professional', 'enterprise', 'institutional', 'government'].includes(user.subscription_tier)) {
    return new Response(JSON.stringify({ 
      error: 'Yield predictions require Professional tier or higher' 
    }), {
      status: 403,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const url = new URL(req.url);
  const maturity = url.searchParams.get('maturity');
  const limit = parseInt(url.searchParams.get('limit') || '50');

  let query = supabase.from('yield_predictions').select('*');

  if (maturity) query = query.eq('maturity', maturity);

  const { data, error } = await query
    .order('prediction_date', { ascending: false })
    .limit(Math.min(limit, 500));

  const executionTime = Date.now() - startTime;
  await logRequest(user.user_id, '/yield-predictions', 'GET', error ? 500 : 200, executionTime);

  if (error) throw error;

  return new Response(JSON.stringify({
    data,
    count: data?.length || 0,
    metadata: {
      endpoint: 'yield-predictions',
      execution_time_ms: executionTime
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
};

const handleAPIUsage = async (req: Request, user: any, startTime: number) => {
  const { data, error } = await supabase
    .from('api_requests')
    .select('*')
    .eq('user_id', user.user_id)
    .order('created_at', { ascending: false })
    .limit(100);

  const executionTime = Date.now() - startTime;
  await logRequest(user.user_id, '/api-usage', 'GET', error ? 500 : 200, executionTime);

  if (error) throw error;

  return new Response(JSON.stringify({
    data,
    count: data?.length || 0,
    user_info: {
      api_calls_remaining: user.api_calls_remaining,
      subscription_tier: user.subscription_tier
    },
    metadata: {
      endpoint: 'api-usage',
      execution_time_ms: executionTime
    }
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
};