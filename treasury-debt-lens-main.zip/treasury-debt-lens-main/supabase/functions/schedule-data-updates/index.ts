import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting scheduled data updates...');
    
    const results = {
      treasury: null,
      fed: null,
      sovereign: null,
      countries: null,
      esg: null
    };

    // Update Treasury data (daily)
    try {
      console.log('Triggering Treasury data update...');
      const treasuryResponse = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'treasury' }
      });
      results.treasury = treasuryResponse.data;
    } catch (error) {
      console.error('Treasury update failed:', error);
      results.treasury = { error: error.message };
    }

    // Update Fed data (weekly)
    const dayOfWeek = new Date().getDay();
    if (dayOfWeek === 1) { // Monday
      try {
        console.log('Triggering Fed data update...');
        const fedResponse = await supabase.functions.invoke('data-ingestion', {
          body: { action: 'fed' }
        });
        results.fed = fedResponse.data;
      } catch (error) {
        console.error('Fed update failed:', error);
        results.fed = { error: error.message };
      }
    }

    // Update sovereign debt data (monthly)
    const dayOfMonth = new Date().getDate();
    if (dayOfMonth === 1) { // First day of month
      try {
        console.log('Triggering sovereign debt update...');
        const sovereignResponse = await supabase.functions.invoke('data-ingestion', {
          body: { action: 'sovereign' }
        });
        results.sovereign = sovereignResponse.data;
      } catch (error) {
        console.error('Sovereign debt update failed:', error);
        results.sovereign = { error: error.message };
      }

      // Also update countries data monthly
      try {
        console.log('Triggering countries data update...');
        const countriesResponse = await supabase.functions.invoke('data-ingestion', {
          body: { action: 'countries' }
        });
        results.countries = countriesResponse.data;
      } catch (error) {
        console.error('Countries update failed:', error);
        results.countries = { error: error.message };
      }
    }

    // Generate ESG scores using AI (quarterly)
    const month = new Date().getMonth();
    if (month % 3 === 0 && dayOfMonth === 15) { // Mid-month of quarters
      try {
        console.log('Triggering ESG score generation...');
        results.esg = await generateESGScores();
      } catch (error) {
        console.error('ESG generation failed:', error);
        results.esg = { error: error.message };
      }
    }

    // Log schedule run
    await supabase.from('ai_model_runs').insert({
      model_type: 'data_scheduler',
      input_data: { 
        timestamp: new Date().toISOString(),
        day_of_week: dayOfWeek,
        day_of_month: dayOfMonth
      },
      output_data: results,
      model_version: 'scheduler-v1',
      confidence_score: 1.0,
      execution_time_ms: Date.now() - new Date().getTime()
    });

    console.log('Scheduled updates completed');

    return new Response(JSON.stringify({
      success: true,
      message: 'Scheduled data updates completed',
      results,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in scheduled updates:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function generateESGScores() {
  const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!openAIApiKey) {
    throw new Error('OpenAI API key not configured');
  }

  // Get all countries
  const { data: countries, error } = await supabase
    .from('countries')
    .select('*')
    .limit(50); // Process in batches

  if (error) {
    throw error;
  }

  const results = [];

  for (const country of countries || []) {
    try {
      console.log(`Generating ESG scores for ${country.name}...`);
      
      // Get recent economic data for context
      const { data: debtData } = await supabase
        .from('sovereign_debt')
        .select('*')
        .eq('country_id', country.id)
        .order('year', { ascending: false })
        .limit(5);

      // Generate ESG assessment using AI
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{
            role: 'system',
            content: `You are an ESG analyst specializing in sovereign risk assessment. 
            Analyze the provided country data and generate ESG scores (0-100 scale) based on:
            - Environmental: Climate policies, renewable energy, carbon emissions
            - Social: Healthcare, education, inequality, human rights
            - Governance: Political stability, corruption, transparency, rule of law
            
            Provide scores in JSON format:
            {
              "environmental_score": <number>,
              "social_score": <number>, 
              "governance_score": <number>,
              "overall_score": <number>,
              "fiscal_transparency_score": <number>,
              "debt_sustainability_score": <number>,
              "key_factors": ["factor1", "factor2", "factor3"]
            }`
          }, {
            role: 'user',
            content: `Assess ESG scores for ${country.name}:
            Region: ${country.region}
            Income Level: ${country.income_level}
            Population: ${country.population?.toLocaleString() || 'N/A'}
            GDP: $${country.gdp_usd?.toLocaleString() || 'N/A'}
            Recent Debt Data: ${JSON.stringify(debtData?.slice(0, 3) || [])}`
          }],
          temperature: 0.3,
          max_tokens: 800
        }),
      });

      const aiData = await response.json();
      
      if (!aiData.choices?.[0]) {
        console.error(`No AI response for ${country.name}`);
        continue;
      }

      let esgData;
      try {
        esgData = JSON.parse(aiData.choices[0].message.content);
      } catch (parseError) {
        console.error(`JSON parse error for ${country.name}:`, parseError);
        continue;
      }

      // Store ESG scores
      const { error: insertError } = await supabase
        .from('esg_scores')
        .upsert({
          country_id: country.id,
          assessment_date: new Date().toISOString().split('T')[0],
          environmental_score: esgData.environmental_score,
          social_score: esgData.social_score,
          governance_score: esgData.governance_score,
          overall_score: esgData.overall_score,
          fiscal_transparency_score: esgData.fiscal_transparency_score,
          debt_sustainability_score: esgData.debt_sustainability_score,
          methodology_version: 'ai-quarterly-v1'
        }, { onConflict: 'country_id,assessment_date' });

      if (insertError) {
        console.error(`Error storing ESG for ${country.name}:`, insertError);
      } else {
        results.push({ country: country.name, scores: esgData });
      }

      // Rate limit
      await new Promise(resolve => setTimeout(resolve, 1000));

    } catch (error) {
      console.error(`Error processing ESG for ${country.name}:`, error);
    }
  }

  return { processed: results.length, countries: countries?.length || 0 };
}