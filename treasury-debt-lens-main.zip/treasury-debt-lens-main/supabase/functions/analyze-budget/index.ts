import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

console.log('Starting analyze-budget function...');

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

console.log('Environment check:', {
  hasOpenAI: !!openAIApiKey,
  hasSupabaseUrl: !!supabaseUrl,
  hasSupabaseKey: !!supabaseKey
});

const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('Analyze budget function called:', req.method);
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Processing request...');
    
    const formData = await req.formData();
    console.log('Form data received');
    
    const file = formData.get('budget_file') as File;
    const countryId = formData.get('country_id') as string;
    const fiscalYear = parseInt(formData.get('fiscal_year') as string);
    const currency = formData.get('currency') as string;

    console.log('Parsed data:', { 
      fileName: file?.name, 
      countryId, 
      fiscalYear, 
      currency 
    });

    if (!file || !countryId || !fiscalYear || !currency) {
      console.error('Missing required fields');
      return new Response(JSON.stringify({ 
        error: 'Missing required fields: budget_file, country_id, fiscal_year, currency' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const fileContent = await file.text();
    
    if (!openAIApiKey) {
      console.log('OpenAI API key not found - generating mock analysis');
      
      // Generate mock analysis when API key not available
      const analysis = {
        total_revenue: Math.floor(Math.random() * 1000000) + 500000,
        total_expenditure: Math.floor(Math.random() * 1200000) + 600000,
        budget_balance: Math.floor(Math.random() * 200000) - 100000,
        primary_balance: Math.floor(Math.random() * 150000) - 75000,
        debt_sustainability_score: Math.floor(Math.random() * 30) + 60,
        fiscal_transparency_score: Math.floor(Math.random() * 25) + 65,
        esg_analysis: {
          environmental_commitments: "Mock analysis - environmental spending increased by 15%",
          social_programs: "Mock analysis - social programs allocation maintained",
          governance_measures: "Mock analysis - transparency initiatives implemented",
          overall_esg_score: Math.floor(Math.random() * 20) + 70
        },
        key_insights: [
          "Budget analysis completed using mock data",
          "OpenAI API not configured - showing sample results",
          "Upload successful, document processed"
        ],
        risk_assessment: "Mock risk assessment - moderate fiscal position with room for improvement",
        summary: `Mock budget analysis for ${fiscalYear}. Total revenue estimated at ${analysis.total_revenue} ${currency}, expenditure at ${analysis.total_expenditure} ${currency}. OpenAI API not configured - showing demonstration results.`
      };

      // Store budget analysis in database
      const { data: budget, error: insertError } = await supabase
        .from('government_budgets')
        .insert({
          country_id: countryId,
          fiscal_year: fiscalYear,
          currency: currency,
          total_revenue: analysis.total_revenue,
          total_expenditure: analysis.total_expenditure,
          budget_balance: analysis.budget_balance,
          primary_balance: analysis.primary_balance,
          document_url: null,
          pdf_text: `Mock analysis of uploaded document: ${file.name}`,
          ai_summary: analysis.summary,
          esg_analysis: analysis.esg_analysis,
          processed_at: new Date().toISOString()
        })
        .select()
        .single();

      if (insertError) {
        console.error('Error storing mock budget analysis:', insertError);
        throw insertError;
      }

      // Store ESG scores
      await supabase.from('esg_scores').insert({
        country_id: countryId,
        assessment_date: new Date().toISOString().split('T')[0],
        environmental_score: analysis.esg_analysis.environmental_score || 65,
        social_score: analysis.esg_analysis.social_score || 70,
        governance_score: analysis.esg_analysis.governance_score || 68,
        overall_score: analysis.esg_analysis.overall_esg_score,
        fiscal_transparency_score: analysis.fiscal_transparency_score,
        debt_sustainability_score: analysis.debt_sustainability_score,
        methodology_version: 'mock-budget-analysis-v1'
      });

      // Log AI model run
      await supabase.from('ai_model_runs').insert({
        model_type: 'budget_analysis',
        input_data: { 
          country_id: countryId, 
          fiscal_year: fiscalYear,
          file_size: fileContent.length,
          mock: true
        },
        output_data: analysis,
        model_version: 'mock-v1',
        confidence_score: 0.65,
        execution_time_ms: 200
      });

      return new Response(JSON.stringify({
        success: true,
        budget_id: budget.id,
        analysis: {
          ...analysis,
          processed_at: new Date().toISOString(),
          mock: true
        }
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Parsed data:', { 
      fileName: file?.name, 
      countryId, 
      fiscalYear, 
      currency 
    });

    if (!file || !countryId || !fiscalYear || !currency) {
      console.error('Missing required fields');
      return new Response(JSON.stringify({ 
        error: 'Missing required fields: budget_file, country_id, fiscal_year, currency' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Analyzing budget document: ${file.name} for country ${countryId}, FY ${fiscalYear}`);

    // Read file content (simplified - in production you'd use pdf-parse or similar)
    const fileContent = await file.text();
    const truncatedContent = fileContent.substring(0, 8000); // Limit for token constraints

    console.log(`File content length: ${fileContent.length}, truncated to: ${truncatedContent.length}`);

    // Analyze with OpenAI
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [{
          role: 'system',
          content: `You are a financial analyst specializing in government budget analysis. 
          Analyze the provided government budget document and extract key fiscal metrics, 
          identify ESG commitments, and assess debt sustainability risks.
          
          Provide analysis in this JSON format:
          {
            "total_revenue": <number or null>,
            "total_expenditure": <number or null>,
            "budget_balance": <number or null>,
            "primary_balance": <number or null>,
            "debt_sustainability_score": <number 0-100>,
            "fiscal_transparency_score": <number 0-100>,
            "esg_analysis": {
              "environmental_commitments": "<description>",
              "social_programs": "<description>",
              "governance_measures": "<description>",
              "overall_esg_score": <number 0-100>
            },
            "key_insights": [
              "<insight 1>",
              "<insight 2>",
              "<insight 3>"
            ],
            "risk_assessment": "<assessment>",
            "summary": "<executive summary>"
          }`
        }, {
          role: 'user',
          content: `Analyze this government budget document:\n\n${truncatedContent}`
        }],
        temperature: 0.3,
        max_tokens: 2000
      }),
    });

    const aiData = await response.json();
    console.log('OpenAI analysis completed');

    if (!aiData.choices || !aiData.choices[0]) {
      throw new Error('Invalid response from OpenAI');
    }

    let analysis;
    try {
      let content = aiData.choices[0].message.content;
      // Clean content - remove markdown code blocks and escape sequences
      content = content.replace(/```json\n?/g, '').replace(/```\n?/g, '');
      content = content.replace(/\\u0000/g, ''); // Remove null Unicode characters
      content = content.trim();
      
      analysis = JSON.parse(content);
    } catch (parseError) {
      console.error('Error parsing AI response:', parseError);
      console.log('Raw content:', aiData.choices[0].message.content);
      
      // Fallback to structured defaults with raw text
      analysis = {
        total_revenue: null,
        total_expenditure: null,
        budget_balance: null,
        primary_balance: null,
        debt_sustainability_score: 75,
        fiscal_transparency_score: 70,
        esg_analysis: { 
          environmental_commitments: "Analysis unavailable - parsing error",
          social_programs: "Analysis unavailable - parsing error", 
          governance_measures: "Analysis unavailable - parsing error",
          overall_esg_score: 50 
        },
        key_insights: ["Budget document uploaded successfully", "AI analysis encountered formatting issues"],
        risk_assessment: "Standard risk assessment - detailed analysis unavailable",
        summary: aiData.choices[0].message.content.substring(0, 1000) // Truncate to avoid Unicode issues
      };
    }

    // Store budget analysis in database
    const { data: budget, error: insertError } = await supabase
      .from('government_budgets')
      .insert({
        country_id: countryId,
        fiscal_year: fiscalYear,
        currency: currency,
        total_revenue: analysis.total_revenue,
        total_expenditure: analysis.total_expenditure,
        budget_balance: analysis.budget_balance,
        primary_balance: analysis.primary_balance,
        document_url: null, // Would store actual file URL in production
        pdf_text: truncatedContent,
        ai_summary: analysis.summary,
        esg_analysis: analysis.esg_analysis,
        processed_at: new Date().toISOString()
      })
      .select()
      .single();

    if (insertError) {
      console.error('Error storing budget analysis:', insertError);
      throw insertError;
    }

    // Store ESG scores if available
    if (analysis.esg_analysis) {
      await supabase.from('esg_scores').insert({
        country_id: countryId,
        assessment_date: new Date().toISOString().split('T')[0],
        environmental_score: analysis.esg_analysis.environmental_score || 50,
        social_score: analysis.esg_analysis.social_score || 50,
        governance_score: analysis.esg_analysis.governance_score || 50,
        overall_score: analysis.esg_analysis.overall_esg_score || 50,
        fiscal_transparency_score: analysis.fiscal_transparency_score || 50,
        debt_sustainability_score: analysis.debt_sustainability_score || 50,
        methodology_version: 'ai-budget-analysis-v1'
      });
    }

    // Log AI model run
    await supabase.from('ai_model_runs').insert({
      model_type: 'budget_analysis',
      input_data: { 
        country_id: countryId, 
        fiscal_year: fiscalYear,
        file_size: fileContent.length 
      },
      output_data: analysis,
      model_version: 'gpt-4o-mini-v1',
      confidence_score: 0.75,
      execution_time_ms: Date.now() - new Date().getTime()
    });

    console.log('Budget analysis completed successfully');

    return new Response(JSON.stringify({
      success: true,
      budget_id: budget.id,
      analysis: {
        ...analysis,
        processed_at: new Date().toISOString()
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in budget analysis:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});