import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
const fredApiKey = Deno.env.get('FRED_API_KEY');

const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Treasury yield series from FRED
const TREASURY_SERIES = {
  '1M': 'GS1M',
  '3M': 'GS3M', 
  '6M': 'GS6M',
  '1Y': 'GS1',
  '2Y': 'GS2',
  '3Y': 'GS3',
  '5Y': 'GS5',
  '7Y': 'GS7',
  '10Y': 'GS10',
  '20Y': 'GS20',
  '30Y': 'GS30'
};

// Fed Funds Rate series
const FED_FUNDS_SERIES = 'FEDFUNDS';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    let action = 'all';
    
    // Try to get action from request body first, then URL params
    try {
      const body = await req.json();
      if (body.action) {
        action = body.action;
      }
    } catch {
      // If JSON parsing fails, try URL params
      const url = new URL(req.url);
      action = url.searchParams.get('action') || 'all';
    }
    
    console.log(`Starting data ingestion: ${action}`);

    let results = {};

    if (action === 'treasury' || action === 'all') {
      console.log('Updating Treasury yields...');
      results.treasury = await updateTreasuryYields();
    }

    if (action === 'fed' || action === 'all') {
      console.log('Updating Fed data...');
      results.fed = await updateFedData();
    }

    if (action === 'sovereign' || action === 'all') {
      console.log('Updating sovereign debt data...');
      results.sovereign = await updateSovereignDebt();
    }

    if (action === 'countries' || action === 'all') {
      console.log('Updating country data...');
      results.countries = await updateCountriesData();
    }

    console.log('Data ingestion completed successfully');

    return new Response(JSON.stringify({
      success: true,
      message: 'Data ingestion completed',
      results,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in data ingestion:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function updateTreasuryYields() {
  if (!fredApiKey) {
    throw new Error('FRED API key not configured');
  }

  const results = [];
  
  for (const [maturity, seriesId] of Object.entries(TREASURY_SERIES)) {
    try {
      console.log(`Fetching ${maturity} Treasury yields...`);
      
      // Get last 30 days of data
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 30);
      const startDateStr = startDate.toISOString().split('T')[0];
      
      const response = await fetch(
        `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&api_key=${fredApiKey}&file_type=json&observation_start=${startDateStr}&limit=1000`
      );
      
      if (!response.ok) {
        console.error(`FRED API error for ${maturity}:`, response.status, response.statusText);
        continue;
      }
      
      const data = await response.json();
      
      if (!data.observations) {
        console.log(`No observations for ${maturity}`);
        continue;
      }

      const validObservations = data.observations.filter(obs => 
        obs.value !== '.' && !isNaN(parseFloat(obs.value))
      );

      if (validObservations.length === 0) {
        console.log(`No valid data for ${maturity}`);
        continue;
      }

      // Upsert data
      const { data: insertResult, error } = await supabase
        .from('treasury_yields')
        .upsert(
          validObservations.map(obs => ({
            date: obs.date,
            maturity,
            yield_rate: parseFloat(obs.value),
            source: 'FRED'
          })),
          { onConflict: 'date,maturity' }
        );

      if (error) {
        console.error(`Error inserting ${maturity} data:`, error);
      } else {
        console.log(`Successfully updated ${validObservations.length} records for ${maturity}`);
        results.push({ maturity, records: validObservations.length });
      }

      // Rate limit: 120 calls per minute
      await new Promise(resolve => setTimeout(resolve, 500));

    } catch (error) {
      console.error(`Error processing ${maturity}:`, error);
    }
  }

  return results;
}

async function updateFedData() {
  if (!fredApiKey) {
    throw new Error('FRED API key not configured');
  }

  try {
    console.log('Fetching Fed Funds Rate data...');
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 365); // Last year
    const startDateStr = startDate.toISOString().split('T')[0];
    
    const response = await fetch(
      `https://api.stlouisfed.org/fred/series/observations?series_id=${FED_FUNDS_SERIES}&api_key=${fredApiKey}&file_type=json&observation_start=${startDateStr}&limit=1000`
    );
    
    if (!response.ok) {
      throw new Error(`FRED API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.observations) {
      return { message: 'No Fed data available' };
    }

    const validObservations = data.observations.filter(obs => 
      obs.value !== '.' && !isNaN(parseFloat(obs.value))
    );

    // Create meeting records for rate changes
    let lastRate = null;
    const meetingRecords = [];

    for (const obs of validObservations) {
      const currentRate = parseFloat(obs.value);
      
      if (lastRate !== null && Math.abs(currentRate - lastRate) >= 0.01) {
        // Significant rate change detected
        const rateChange = currentRate - lastRate;
        
        meetingRecords.push({
          meeting_date: obs.date,
          fed_funds_rate: currentRate,
          rate_decision: rateChange > 0 ? 'increase' : 'decrease',
          decision_magnitude: Math.abs(rateChange) * 100, // Convert to basis points
          created_at: new Date().toISOString()
        });
      }
      
      lastRate = currentRate;
    }

    if (meetingRecords.length > 0) {
      const { error } = await supabase
        .from('fed_meetings')
        .upsert(meetingRecords, { onConflict: 'meeting_date' });

      if (error) {
        console.error('Error inserting Fed meeting data:', error);
        throw error;
      }

      console.log(`Successfully updated ${meetingRecords.length} Fed meeting records`);
    }

    return { records: meetingRecords.length };

  } catch (error) {
    console.error('Error updating Fed data:', error);
    throw error;
  }
}

async function updateSovereignDebt() {
  try {
    console.log('Fetching World Bank debt data...');
    
    // World Bank API - Debt to GDP ratio for all countries
    const debtResponse = await fetch(
      'https://api.worldbank.org/v2/country/all/indicator/GC.DOD.TOTL.GD.ZS?format=json&per_page=5000&date=2020:2023'
    );
    
    if (!debtResponse.ok) {
      throw new Error(`World Bank API error: ${debtResponse.status}`);
    }
    
    const debtData = await debtResponse.json();
    
    if (!Array.isArray(debtData) || debtData.length < 2) {
      throw new Error('Invalid World Bank response format');
    }

    const debtRecords = debtData[1]
      .filter(record => record.value !== null && record.country?.id !== 'WLD')
      .map(record => ({
        country_iso: record.country.id,
        country_name: record.country.value,
        year: parseInt(record.date),
        debt_to_gdp: parseFloat(record.value)
      }));

    console.log(`Processing ${debtRecords.length} debt records...`);

    // Get or create countries first
    const uniqueCountries = [...new Map(
      debtRecords.map(r => [r.country_iso, { iso_code: r.country_iso, name: r.country_name }])
    ).values()];

    for (const country of uniqueCountries) {
      await supabase
        .from('countries')
        .upsert(country, { onConflict: 'iso_code' });
    }

    // Get country IDs
    const { data: countries } = await supabase
      .from('countries')
      .select('id, iso_code');

    const countryMap = new Map(countries?.map(c => [c.iso_code, c.id]) || []);

    // Insert debt data
    const debtInserts = debtRecords
      .filter(record => countryMap.has(record.country_iso))
      .map(record => ({
        country_id: countryMap.get(record.country_iso),
        year: record.year,
        debt_to_gdp: record.debt_to_gdp
      }));

    if (debtInserts.length > 0) {
      const { error } = await supabase
        .from('sovereign_debt')
        .upsert(debtInserts, { onConflict: 'country_id,year' });

      if (error) {
        console.error('Error inserting sovereign debt data:', error);
        throw error;
      }

      console.log(`Successfully updated ${debtInserts.length} sovereign debt records`);
    }

    return { countries: uniqueCountries.length, debt_records: debtInserts.length };

  } catch (error) {
    console.error('Error updating sovereign debt:', error);
    throw error;
  }
}

async function updateCountriesData() {
  try {
    console.log('Fetching World Bank country data...');
    
    // Get country metadata
    const countryResponse = await fetch(
      'https://api.worldbank.org/v2/country?format=json&per_page=500'
    );
    
    if (!countryResponse.ok) {
      throw new Error(`World Bank API error: ${countryResponse.status}`);
    }
    
    const countryData = await countryResponse.json();
    
    if (!Array.isArray(countryData) || countryData.length < 2) {
      throw new Error('Invalid World Bank response format');
    }

    const countries = countryData[1]
      .filter(country => 
        country.iso2Code && 
        country.iso2Code !== '' && 
        country.region?.value !== 'Aggregates'
      )
      .map(country => ({
        iso_code: country.iso2Code,
        name: country.name,
        region: country.region?.value || null,
        income_level: country.incomeLevel?.value || null
      }));

    console.log(`Processing ${countries.length} countries...`);

    // Get population and GDP data
    const [popResponse, gdpResponse] = await Promise.all([
      fetch('https://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL?format=json&per_page=1000&date=2022'),
      fetch('https://api.worldbank.org/v2/country/all/indicator/NY.GDP.MKTP.CD?format=json&per_page=1000&date=2022')
    ]);

    const popData = await popResponse.json();
    const gdpData = await gdpResponse.json();

    // Create maps for population and GDP
    const popMap = new Map();
    const gdpMap = new Map();

    if (Array.isArray(popData) && popData[1]) {
      popData[1].forEach(record => {
        if (record.value && record.country?.id) {
          popMap.set(record.country.id, parseInt(record.value));
        }
      });
    }

    if (Array.isArray(gdpData) && gdpData[1]) {
      gdpData[1].forEach(record => {
        if (record.value && record.country?.id) {
          gdpMap.set(record.country.id, parseInt(record.value));
        }
      });
    }

    // Merge data
    const countryRecords = countries.map(country => ({
      ...country,
      population: popMap.get(country.iso_code) || null,
      gdp_usd: gdpMap.get(country.iso_code) || null
    }));

    // Upsert countries
    const { error } = await supabase
      .from('countries')
      .upsert(countryRecords, { onConflict: 'iso_code' });

    if (error) {
      console.error('Error inserting country data:', error);
      throw error;
    }

    console.log(`Successfully updated ${countryRecords.length} country records`);

    return { records: countryRecords.length };

  } catch (error) {
    console.error('Error updating countries data:', error);
    throw error;
  }
}