import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const supabase = createClient(supabaseUrl!, supabaseKey!);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting initial data load for all 195 countries...');
    
    const startTime = Date.now();
    const results = {
      phase1: null,
      phase2: null,
      phase3: null,
      totalTime: 0
    };

    // Phase 1: Load countries and basic data
    console.log('Phase 1: Loading countries and sovereign debt data...');
    try {
      const phase1Response = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'countries' }
      });
      results.phase1 = phase1Response.data;
      
      // Also load sovereign debt data
      const sovereignResponse = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'sovereign' }
      });
      results.phase1.sovereign = sovereignResponse.data;
      
    } catch (error) {
      console.error('Phase 1 error:', error);
      results.phase1 = { error: error.message };
    }

    // Phase 2: Load US Treasury and Fed data
    console.log('Phase 2: Loading US Treasury and Fed data...');
    try {
      const treasuryResponse = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'treasury' }
      });
      results.phase2 = treasuryResponse.data;
      
      const fedResponse = await supabase.functions.invoke('data-ingestion', {
        body: { action: 'fed' }
      });
      results.phase2.fed = fedResponse.data;
      
    } catch (error) {
      console.error('Phase 2 error:', error);
      results.phase2 = { error: error.message };
    }

    // Phase 3: Generate initial ESG scores for top economies
    console.log('Phase 3: Generating ESG scores for major economies...');
    try {
      results.phase3 = await generateInitialESGScores();
    } catch (error) {
      console.error('Phase 3 error:', error);
      results.phase3 = { error: error.message };
    }

    results.totalTime = Date.now() - startTime;
    
    // Verify data completeness
    const dataCheck = await verifyDataCompleteness();
    
    console.log('Initial data load completed');

    return new Response(JSON.stringify({
      success: true,
      message: 'Initial data load completed for all countries',
      results,
      dataCheck,
      executionTimeMs: results.totalTime,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in initial data load:', error);
    return new Response(JSON.stringify({
      error: error.message,
      success: false
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function generateInitialESGScores() {
  const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
  
  if (!openAIApiKey) {
    return { message: 'OpenAI API key not configured, skipping ESG generation' };
  }

  // Get major economies (G20 countries)
  const g20Countries = [
    'US', 'CN', 'JP', 'DE', 'IN', 'GB', 'FR', 'IT', 'BR', 'CA',
    'RU', 'KR', 'ES', 'AU', 'MX', 'ID', 'NL', 'SA', 'TR', 'CH'
  ];

  const { data: countries } = await supabase
    .from('countries')
    .select('*')
    .in('iso_code', g20Countries);

  if (!countries) {
    return { error: 'No countries found' };
  }

  const results = [];

  for (const country of countries) {
    try {
      console.log(`Generating ESG scores for ${country.name}...`);
      
      // Get economic context
      const { data: debtData } = await supabase
        .from('sovereign_debt')
        .select('*')
        .eq('country_id', country.id)
        .order('year', { ascending: false })
        .limit(3);

      // Generate comprehensive ESG assessment
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAIApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [{
            role: 'system',
            content: `You are a senior ESG analyst with expertise in sovereign risk assessment. 
            
            Provide comprehensive ESG scores (0-100 scale) based on current global standards:
            
            Environmental (E):
            - Climate commitments & policies (Paris Agreement compliance)
            - Renewable energy transition
            - Carbon emissions per capita
            - Environmental regulations & enforcement
            - Natural resource management
            
            Social (S):
            - Healthcare system quality & accessibility
            - Education system & literacy rates
            - Income inequality (Gini coefficient)
            - Human rights record
            - Social safety nets
            - Labor standards
            
            Governance (G):
            - Political stability & effectiveness
            - Rule of law & judicial independence
            - Corruption levels (Transparency International)
            - Regulatory quality
            - Democratic institutions
            - Press freedom
            
            Additional Fiscal Metrics:
            - Budget transparency & accountability
            - Debt sustainability & management
            
            Respond with JSON only:
            {
              "environmental_score": <number 0-100>,
              "social_score": <number 0-100>,
              "governance_score": <number 0-100>, 
              "overall_score": <number 0-100>,
              "fiscal_transparency_score": <number 0-100>,
              "debt_sustainability_score": <number 0-100>,
              "sdg_alignment": {
                "SDG1": <poverty reduction score>,
                "SDG3": <health score>,
                "SDG4": <education score>,
                "SDG7": <clean energy score>,
                "SDG13": <climate action score>,
                "SDG16": <governance score>
              },
              "strengths": ["strength1", "strength2", "strength3"],
              "challenges": ["challenge1", "challenge2", "challenge3"]
            }`
          }, {
            role: 'user',
            content: `Assess comprehensive ESG scores for ${country.name}:
            
            Country Profile:
            - ISO Code: ${country.iso_code}
            - Region: ${country.region}
            - Income Level: ${country.income_level}
            - Population: ${country.population?.toLocaleString() || 'N/A'}
            - GDP (USD): $${country.gdp_usd?.toLocaleString() || 'N/A'}
            
            Recent Debt-to-GDP Ratios: ${JSON.stringify(debtData?.map(d => ({ year: d.year, debt_to_gdp: d.debt_to_gdp })) || [])}
            
            Please provide accurate, research-based scores reflecting the current ESG performance of this country.`
          }],
          temperature: 0.2,
          max_tokens: 1200
        }),
      });

      const aiData = await response.json();
      
      if (!aiData.choices?.[0]) {
        console.error(`No AI response for ${country.name}`);
        continue;
      }

      let esgData;
      try {
        esgData = JSON.parse(aiData.choices[0].message.content);
      } catch (parseError) {
        console.error(`JSON parse error for ${country.name}:`, parseError);
        continue;
      }

      // Store comprehensive ESG data
      const { error: insertError } = await supabase
        .from('esg_scores')
        .insert({
          country_id: country.id,
          assessment_date: new Date().toISOString().split('T')[0],
          environmental_score: esgData.environmental_score,
          social_score: esgData.social_score,
          governance_score: esgData.governance_score,
          overall_score: esgData.overall_score,
          sdg_alignment: esgData.sdg_alignment,
          fiscal_transparency_score: esgData.fiscal_transparency_score,
          debt_sustainability_score: esgData.debt_sustainability_score,
          methodology_version: 'ai-comprehensive-v1'
        });

      if (insertError) {
        console.error(`Error storing ESG for ${country.name}:`, insertError);
      } else {
        results.push({ 
          country: country.name, 
          iso_code: country.iso_code,
          overall_score: esgData.overall_score,
          scores: {
            environmental: esgData.environmental_score,
            social: esgData.social_score,
            governance: esgData.governance_score
          }
        });
        console.log(`✓ ESG scores generated for ${country.name}`);
      }

      // Rate limiting for API calls
      await new Promise(resolve => setTimeout(resolve, 1500));

    } catch (error) {
      console.error(`Error processing ESG for ${country.name}:`, error);
    }
  }

  return { 
    processed: results.length, 
    total_countries: countries.length,
    results: results.slice(0, 10) // First 10 for summary
  };
}

async function verifyDataCompleteness() {
  try {
    const [
      { count: countryCount },
      { count: treasuryCount },
      { count: debtCount },
      { count: esgCount },
      { count: fedCount }
    ] = await Promise.all([
      supabase.from('countries').select('*', { count: 'exact', head: true }),
      supabase.from('treasury_yields').select('*', { count: 'exact', head: true }),
      supabase.from('sovereign_debt').select('*', { count: 'exact', head: true }),
      supabase.from('esg_scores').select('*', { count: 'exact', head: true }),
      supabase.from('fed_meetings').select('*', { count: 'exact', head: true })
    ]);

    return {
      countries: countryCount,
      treasury_yields: treasuryCount,
      sovereign_debt: debtCount,
      esg_scores: esgCount,
      fed_meetings: fedCount,
      data_coverage: {
        countries_target: 195,
        countries_actual: countryCount,
        coverage_percentage: Math.round((countryCount / 195) * 100)
      }
    };
  } catch (error) {
    console.error('Error verifying data:', error);
    return { error: error.message };
  }
}